import React from 'react';
import NavigationBar from './Components/NavigationBar/NavigationBar';
import Map from './Components/Map/Map';
import $ from 'jquery';
import { encryptData, decryptData } from './Utils';

const addressApiFailureMsg = 'Unable to fetch the address of the marker location';

class App extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			position: null,
			address: null,
		};
	};


	// getUrlVars() {
	// 	let vars = [], hash;
	// 	let hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	// 	for (let i = 0; i < hashes.length; i++) {
	// 		hash = hashes[i].split('=');
	// 		vars.push(hash[0]);
	// 		vars[hash[0]] = hash[1];
	// 	}
	// 	return vars;
	// }
 
	setPosition = (position) => {
		this.setState({ position });
		if(position !== null) {
			const getAddrpayload = encryptData(JSON.stringify({
				lat: position.lat,
				lng: position.lng
			  }));
			this.doReverseGeocodingApi(getAddrpayload)
		}
	}
	setAddress = (address) => {
		this.setState({ address });
	}


	doReverseGeocodingApi = (payload) => {
		const that = this;
		$.post("http://localhost:53400/api/plm/GetAddress", {input: payload}, function (res) {
		  const response = JSON.parse(decryptData(res));
		  that.setAddress(response);
	
		  // that.setState({
		  //   address: response
		  // })
		})
		  .fail(() => {
			that.setAddress(addressApiFailureMsg);
			// that.setState({
			//   address: 'Unable to fetch the address of the marker location',
			// })
		  })
	  }

	render() {
		const phoneno = decryptData(this.props.match.params.id)
		return (
			<div style={{"height":"100%"}}>
				<div className="navContainer">
					<NavigationBar
						position={this.state.position}
						address={this.state.address}
						phoneno={phoneno}
						
					/>
				</div>
				<div className="mapContainer">
					<Map
						isMarkerShown
						setPosition={this.setPosition}
						setAddress={this.setAddress}
					/>
				</div>
				<div className="app-footer pa">
					Copyright © 2020 Reliance Jio Infocomm Ltd. All rights reserved.!
				</div>
			</div>
		);
	}
};

export default App;