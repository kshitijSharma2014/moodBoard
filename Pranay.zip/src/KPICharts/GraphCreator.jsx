import React, { Component } from 'react';
import Select from 'react-select';
import _map from 'lodash/map';
import './styles.css';
const customStyles = (color) => {
    return {
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                color: color,
                fontSize: '12px',
                textAlign: 'left',
            }
        }
    }
};

const optionsMultiselect = [
    {
        value: "travel_mode",
        label: "Travel Mode"
    },
    {
        value: "claim_status",
        label: "Claim Status"
    }
];

const selectButtons = {
    "travel_mode": {
        id: 'travel_modeSelectBox',
        heading: "select travel mode",
        onChange: 'onTravelModeChange',
        valueField: 'travel_mode',
        data: [
            {
                value: 2,
                label: "Two Wheeler"
            },
            {
                value: 4,
                label: "Four Wheeler"
            }
        ]
    },
    "claim_status": {
        id: 'claim_statusSelectBox',
        heading: "select claim status",
        onChange: 'onClaimStatusChange',
        valueField: 'claim_status',
        data: [
            {
                value: "UP",
                label: "Under Process"
            },
            {
                value: "UI",
                label: "Under Initiation Process"
            },
            {
                value: "R",
                label: "Rejected"
            },
            {
                value: "P",
                label: "Pending for Manager Approval"
            },
            {
                value: "UX",
                label: "Exception Occured"
            },
            {
                value: "A",
                label: "Approved"
            }
        ]
    }
};

class GraphCreator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            multiSelectValues: [],
            travel_mode: null,
            claim_status: null,
        };
    }
    onSelectedOptionsChange = (multiSelectValues) => {
        this.setState({
            multiSelectValues: multiSelectValues
        });
    }
    onGenerate = async (name, date1) => {
        console.log(this.props.valueSelect.value);
        console.log(date1);
        let parameters = [];
        this.state.multiSelectValues.map(selectedValue => {
            parameters.push(
                {
                    name: selectedValue.label,
                    values: selectedValue.value
                });
        });
        let dataTo = {
            value: name,
            dateOf: date1,
            parameters: parameters
        };
        console.log(dataTo);
        let data = await fetch(
            'http://localhost:8090/kpis',
            {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json'
                    // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: JSON.stringify(dataTo)
            }
        );
        let dataJson = await data.json();
        dataJson = {
            color: this.props.graph.graphColor,
            name: 'Total claims per day',
            data: dataJson
        };
        return dataJson;
    }


    onClaimStatusChange = (claim_status) => {
        this.setState({claim_status})
    }
    onTravelModeChange = (travel_mode) => {
        this.setState({travel_mode})
    }

    renderSubConfig = (option) => {
        debugger
            return (
                <div style={{marginTop:'8px'}}>
                <Select
                    id={selectButtons[option.value].id}
                    //isMulti
                    noOptionsMessage={() => "No Options Found"}
                    value={this.state[selectButtons[option.value].valueField]}
                    onChange={this[selectButtons[option.value].onChange]}
                    options={selectButtons[option.value].data}
                    placeholder={selectButtons[option.value].heading}
                    styles={customStyles(this.props.graph.graphColor)}
                />
                </div>
            )
    }

    render() {
        // if (false) {
        //     this.onGenerate().then((value) => {
        //         console.log("deep1");
        //         console.log(value);
        //         this.props.pushInSeries(value);
        //     });
        // }
        return (<div class="graphCreatorContainer">
            {/* <select id='selectFilter' ref={(c) => this.selectFilter = c} multiple>
                    <option value='travel_mode'>Travel Mode</option>
                    <option value='claim_status'>Claim Status</option>
                </select> */}
            <Select
                id="claimStatusSelect"
                isMulti
                noOptionsMessage={() => "KPI list is empty"}
                value={this.state.multiSelectValues}
                onChange={this.onSelectedOptionsChange}
                options={optionsMultiselect}
                placeholder='Select Claim Status'
                styles={customStyles(this.props.graph.graphColor)}
            />
            {this.state.multiSelectValues.length>0 && _map(this.state.multiSelectValues, (option) => this.renderSubConfig(option))}
        </div>);
    }
}

export default GraphCreator;