import React, { Component } from 'react';
class OneValue extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
    }
    componentDidMount = async () => {
        console.log(this.props);
        let data = await fetch(this.props.props.data);
        data = await data.text();
        this.setState({
            value: data
        })
    }
    render() {
        return (<div>
            <div>
                <h2>{this.props.props.heading}</h2>
            </div>
            <div>
                <h4>{this.state.value == null ? "loading..." : this.state.value}</h4>
            </div>
        </div>
        );
    }
}

export default OneValue;