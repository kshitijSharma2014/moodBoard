import React, { Component } from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
import GraphCreator from './GraphCreator';
import Select from 'react-select';
import './styles.css';
import { Button, Accordion, Card } from 'react-bootstrap'
const customStyles = {
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
        return {
            ...styles,
            fontSize: '12px',
            textAlign: 'left',
        }
    },
};

class WithTimeCustomMulti extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null,
            graphs: [
                {
                    graphColor: 'red',
                    config: {},
                }
            ]
        }
        this.multiSelect = React.createRef();
        this.state.series = [];
        this.refsOf = {};
    }
    addNewGraphConfig = () => {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return {
            graphColor: color,
            config: {},

        };
    }

    compare = (a, b) => {
        if (a[0] > b[0]) {
            return 1;
        }
        else {
            return -1;
        }
    }
    sleep = (milliseconds) => {
        return new Promise(resolve => setTimeout(resolve, milliseconds))
    };
    goButton = async () => {
        this.series = [];
        // for (let i = 0; i < dataJson.length; i++) {
        //     dataJson[i][0] = Date.parse(dataJson[i][0]);
        //     dataJson[i][1] = parseInt(dataJson[i][1]);
        // };
        //dataJson.sort(this.compare);
        let dataSeries = [];
        console.log(this.refsOf);
        for (let i in this.refsOf) {
            console.log(this.state.xAxisSelectedOption.value);
            let data = await this.refsOf[i].onGenerate(this.state.yAxisSelectedOption.value, this.state.xAxisSelectedOption.value);
            dataSeries.push(data);
        }
        // while (this.series.length != this.state.graphs.length) {
        //     await this.sleep(1000);
        //     console.log("deep11");
        // }
        await this.setState({
            series: dataSeries
        });
        console.log("deep");
        //console.log(this.state.series);
        console.log("deep1_1");
    };
    addGraph = () => {
        let newGraph = this.addNewGraphConfig();
        let graphs = this.state.graphs;
        graphs.push(newGraph);
        this.setState({
            graphs: graphs
        });
    }
    pushInSeries = (data) => {
        this.series.push(data);
    }

    onChangeYAxisValue = (yAxisSelectedOption) => {
        this.setState({ yAxisSelectedOption });
    }

    onChangeXAxisValue = (xAxisSelectedOption) => {
        this.setState({ xAxisSelectedOption });
    }

    render = () => {
        let options = {
            chart: {
                zoomType: 'x'
            },
            // rangeSelector: {
            //     allButtonsEnabled: true,
            //     buttons: [{
            //         type: 'month',
            //         count: 3,
            //         text: 'Day',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }, {
            //         type: 'year',
            //         count: 1,
            //         text: 'Week',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }, {
            //         type: 'all',
            //         text: 'Month',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }],
            //     buttonTheme: {
            //         width: 60
            //     },
            //     selected: 2
            // },
            title: {
                text: "Total claims in last 7 days"
            },
            series: this.state.series
        };
        console.log("deep2");
        console.log(options);
        let yAxisOptions = [
            {
                value: "number_of_claims",
                label: "Number of claims"
            },
            {
                value: "total_amount",
                label: "Total amount claimed"
            }
        ];
        let xAxisOptions = [
            {
                value: "RD",
                label: "Date of Journey"
            },
            {
                value: "CD",
                label: "Date on which Claimed"
            }
        ];
        return (<div>
            <div>
                <h2>{this.props.heading}</h2>
            </div>
            <div style={{ width: '100%', height: '90vh' }}>
                <div style={{ width: '25%', float: "right", height: "90vh", overflow: "scroll" }}>
                    <div className="df alignItemsBL">
                        <div>Y axis :</div>
                        <div className="axisselectBoxContainer">
                            <Select
                                id="valueSelect"
                                noOptionsMessage={() => "Value list is empty"}
                                value={this.state.yAxisSelectedOption}
                                onChange={this.onChangeYAxisValue}
                                options={yAxisOptions}
                                placeholder='Select Y Axis Value'
                                styles={customStyles}
                            />
                        </div>
                    </div>
                    <div className="df alignItemsBL">
                        <div>X axis :</div>
                        <div className="axisselectBoxContainer">
                            <Select
                                id="dateSelect"
                                noOptionsMessage={() => "Value list is empty"}
                                value={this.state.xAxisSelectedOption}
                                onChange={this.onChangeXAxisValue}
                                options={xAxisOptions}
                                placeholder='Select X Axis Value'
                                styles={customStyles}
                            />
                        </div>
                    </div>

                    <Accordion defaultActiveKey={this.state.graphs.length - 1} >
                        {this.state.graphs.map((graph, index) => {
                            const color = graph.graphColor;
                            debugger;
                            return (
                                <Card>
                                    <Accordion.Toggle as={Card.Header} eventKey={index} style={{ 'color': `${color}` }}>
                                        {`Graph ${index+1}`}
                                </Accordion.Toggle>
                                    <Accordion.Collapse eventKey={index}>
                                        <Card.Body style={{ 'background': `${color}` }}>
                                            <GraphCreator
                                                graph={graph}
                                                valueSelect={this.state.yAxisSelectedOption}
                                                pushInSeries={this.pushInSeries}
                                            />
                                        </Card.Body>
                                    </Accordion.Collapse>
                                </Card>
                            )
                        }
                        )}
                    </Accordion>
                    <div style={{marginTop: '8px'}}>
                        <Button variant="success" size="sm" onClick={this.addGraph}>Add Graph</Button>
                        {"  "}
                        <Button variant="primary" size="sm" onClick={this.goButton}>Generate Graph</Button>

                    </div>

                    {/* <div>
                <h4 style={{ color: "blue" }}> Total number of claims made per day in last 7 days</h4>
                <h4 style={{ color: "red" }}> Total number of claims pending per day in last 7 days</h4>
                <h4 style={{ color: "green" }}> Total number of claims approved per day in last 7 days</h4>
                <h4 style={{ color: "cyan" }}> Total number of claims made by two wheelers per day in last 7 days</h4>
                <h4 style={{ color: "yellow" }}> Total number of claims made by four wheelers per day in last 7 days</h4>
            </div> */}
                </div>
                <div style={{ width: '70%', float: "left" }}>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            </div>
        </div>
        );
    }
}
export default WithTimeCustomMulti;