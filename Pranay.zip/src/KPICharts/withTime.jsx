import React, { Component } from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
class WithTime extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
    }
    compare = (a, b) => {
        if (a[0] > b[0]) {
            return 1;
        }
        else {
            return -1;
        }
    }
    componentDidMount = async () => {
        let data = await fetch('http://localhost:8086/kpi6');
        let dataJson = await data.json();
        for (let i = 0; i < dataJson.length; i++) {
            dataJson[i][0] = Date.parse(dataJson[i][0]);
            dataJson[i][1] = parseInt(dataJson[i][1]);
        };
        dataJson.sort(this.compare);
        console.log(dataJson);
        await this.setState({
            totalData: dataJson
        });
        let data1 = await fetch('http://localhost:8086/kpi8');
        let dataJson1 = await data1.json();
        for (let i = 0; i < dataJson1.length; i++) {
            dataJson1[i][0] = Date.parse(dataJson1[i][0]);
            dataJson1[i][1] = parseInt(dataJson1[i][1]);
        };
        dataJson1.sort(this.compare);
        console.log(dataJson1);
        await this.setState({
            totalData1: dataJson1
        });
        let data2 = await fetch('http://localhost:8086/kpi7');
        let dataJson2 = await data2.json();
        for (let i = 0; i < dataJson2.length; i++) {
            dataJson2[i][0] = Date.parse(dataJson2[i][0]);
            dataJson2[i][1] = parseInt(dataJson2[i][1]);
        };
        dataJson2.sort(this.compare);
        console.log(dataJson2);
        await this.setState({
            totalData2: dataJson2
        });
        let data3 = await fetch('http://localhost:8086/kpi16');
        let dataJson3 = await data3.json();
        for (let i = 0; i < dataJson3.length; i++) {
            dataJson3[i][0] = Date.parse(dataJson3[i][0]);
            dataJson3[i][1] = parseInt(dataJson3[i][1]);
        };
        dataJson3.sort(this.compare);
        console.log(dataJson3);
        await this.setState({
            totalData3: dataJson3
        });
        let data4 = await fetch('http://localhost:8086/kpi17');
        let dataJson4 = await data4.json();
        for (let i = 0; i < dataJson4.length; i++) {
            dataJson4[i][0] = Date.parse(dataJson4[i][0]);
            dataJson4[i][1] = parseInt(dataJson4[i][1]);
        };
        dataJson4.sort(this.compare);
        console.log(dataJson4);
        await this.setState({
            totalData4: dataJson4
        });

    }
    render() {
        let options = {
            chart: {
                zoomType: 'x'
            },
            title: {
                text: "Total claims in last 7 days"
            },
            series: [{
                color: "blue",
                name: 'Total claims per day',
                data: this.state.totalData
            },
            {
                color: "red",
                name: 'Total claims pending per day',
                data: this.state.totalData1
            },
            {
                color: "green",
                name: 'Total claims approved per day',
                data: this.state.totalData2
            },
            {
                color: "cyan",
                name: 'Total claims made by two wheelers per day',
                data: this.state.totalData3
            },
            {
                color: "yellow",
                name: 'Total claims made by four wheelers per day',
                data: this.state.totalData4
            }
            ]
        };
        return (<div>
            <div>
                <h2>{this.props.heading}</h2>
            </div>
            <div>
                <h4 style={{ color: "blue" }}> Total number of claims made per day in last 7 days</h4>
                <h4 style={{ color: "red" }}> Total number of claims pending per day in last 7 days</h4>
                <h4 style={{ color: "green" }}> Total number of claims approved per day in last 7 days</h4>
                <h4 style={{ color: "cyan" }}> Total number of claims made by two wheelers per day in last 7 days</h4>
                <h4 style={{ color: "yellow" }}> Total number of claims made by four wheelers per day in last 7 days</h4>
            </div>
            <div>
                <HighchartsReact
                    highcharts={Highcharts}
                    constructorType={'stockChart'}
                    options={options}
                />
            </div>
        </div>
        );
    }
}
export default WithTime;