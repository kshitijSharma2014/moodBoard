import React, { Component } from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
class WithTimeCopy extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
    }
    compare = (a, b) => {
        if (a[0] > b[0]) {
            return 1;
        }
        else {
            return -1;
        }
    }
    componentDidMount = async () => {
        let data1 = await fetch('http://localhost:8086/kpi8');
        let dataJson1 = await data1.json();
        for (let i = 0; i < dataJson1.length; i++) {
            dataJson1[i][0] = Date.parse(dataJson1[i][0]);
            dataJson1[i][1] = parseInt(dataJson1[i][1]);
        };
        dataJson1.sort(this.compare);
        console.log(dataJson1);
        await this.setState({
            totalData1: dataJson1
        });
        let data2 = await fetch('http://localhost:8086/kpi7');
        let dataJson2 = await data2.json();
        for (let i = 0; i < dataJson2.length; i++) {
            dataJson2[i][0] = Date.parse(dataJson2[i][0]);
            dataJson2[i][1] = parseInt(dataJson2[i][1]);
        };
        dataJson2.sort(this.compare);
        console.log(dataJson2);
        await this.setState({
            totalData2: dataJson2
        });

    }
    render() {
        let options = {
            chart: {
                zoomType: 'x'
            },
            title: {
                text: "Total claims in last 7 days"
            },
            series: [
                {
                    color: "red",
                    name: 'Total claims pending per day',
                    data: this.state.totalData1
                },
                {
                    color: "green",
                    name: 'Total claims approved per day',
                    data: this.state.totalData2
                }
            ]
        };
        return (<div>
            <div>
                <h2>{this.props.heading}</h2>
            </div>
            <div>
                <h4 style={{ color: "red" }}> Total number of claims pending per day in last 7 days</h4>
                <h4 style={{ color: "green" }}> Total number of claims approved per day in last 7 days</h4>
            </div>
            <div>
                <HighchartsReact
                    highcharts={Highcharts}
                    constructorType={'stockChart'}
                    options={options}
                />
            </div>
        </div>
        );
    }
}
export default WithTimeCopy;