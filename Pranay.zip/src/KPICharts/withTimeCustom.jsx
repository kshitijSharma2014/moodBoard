import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
class WithTimeCustom extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
        this.multiSelect = React.createRef();
        this.valueSelect = React.createRef();
        this.state.selectValues = [];
        this.state.graphs = ['blue'];
        this.selectButtons = {
            "travel_mode": {
                heading: "select travel mode",
                data: [
                    {
                        value: 2,
                        column: "Two Wheeler"
                    },
                    {
                        value: 4,
                        column: "Four Wheeler"
                    }
                ]
            },
            "claim_status": {
                heading: "select claim status",
                data: [
                    {
                        value: "UP",
                        column: "Under Process"
                    },
                    {
                        value: "UI",
                        column: "Under Initiation Process"
                    },
                    {
                        value: "R",
                        column: "Rejected"
                    },
                    {
                        value: "P",
                        column: "Pending for Manager Approval"
                    },
                    {
                        value: "UX",
                        column: "Exception Occured"
                    },
                    {
                        value: "A",
                        column: "Approved"
                    }
                ]
            },
        };
    }
    getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
    compare = (a, b) => {
        if (a[0] > b[0]) {
            return 1;
        }
        else {
            return -1;
        }
    }
    goButton = async () => {
        console.log(this.valueSelect.value);
        console.log(this.selectValues);
        let parameters = [];
        this.state.selectValues.map((selectedValue) => {
            parameters.push(
                {
                    name: selectedValue,
                    values: [this[selectedValue].value]
                });
        });
        let dataTo = {
            value: this.valueSelect.value,
            parameters: parameters
        };
        console.log(dataTo);
        let data = await fetch(
            'http://localhost:8090/kpis',
            {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json'
                    // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: JSON.stringify(dataTo)
            }
        );
        let dataJson = await data.json();
        // for (let i = 0; i < dataJson.length; i++) {
        //     dataJson[i][0] = Date.parse(dataJson[i][0]);
        //     dataJson[i][1] = parseInt(dataJson[i][1]);
        // };
        //dataJson.sort(this.compare);
        console.log(dataJson);
        this.setState({
            dataJson: dataJson
        })

    };
    onSelectedOptionsChange = () => {
        let selectedValues = [...this.multiSelect.selectedOptions];
        let selectValues = [];
        selectedValues.map((selectedValue) => {
            selectValues.push(selectedValue.value);
        })
        console.log(selectValues);
        this.setState({
            selectValues: selectValues
        });
    }
    addGraph = () => {
        let color = this.getRandomColor();
        let graphs = this.state.graphs;
        graphs.push(color);
        this.setState({
            graphs: graphs
        })
    }
    render = () => {
        let options = {
            chart: {
                zoomType: 'x'
            },
            // rangeSelector: {
            //     allButtonsEnabled: true,
            //     buttons: [{
            //         type: 'month',
            //         count: 3,
            //         text: 'Day',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }, {
            //         type: 'year',
            //         count: 1,
            //         text: 'Week',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }, {
            //         type: 'all',
            //         text: 'Month',
            //         dataGrouping: {
            //             forced: true,
            //             units: [['day', [1]]]
            //         }
            //     }],
            //     buttonTheme: {
            //         width: 60
            //     },
            //     selected: 2
            // },
            title: {
                text: "Total claims in last 7 days"
            },
            series: [{
                color: "blue",
                name: 'Total claims per day',
                data: this.state.dataJson
            }]
        };
        let optionsMultiselect = [
            {
                value: "travel_mode",
                name: "Travel Mode"
            },
            {
                value: "claim_status",
                name: "Claim Status"
            }
        ];
        return (<div>
            <div>
                <h2>{this.props.heading}</h2>
            </div>
            <div style={{ width: '100%' }}>
                <div style={{ width: '25%', float: "right", height: '90%', overflowY: "scroll" }}>
                    <div>
                        <h4>Value :</h4>
                        <select id='valueSelect' ref={(c) => this.valueSelect = c}>
                            <option value='number_of_claims'>number of claims</option>
                            <option value='total_amount'>total amount claimed</option>
                        </select>
                    </div>
                    {this.state.graphs.map((graphColor) => (
                        <div style={{ border: '2px solid ' + graphColor, padding: '10px' }}>
                            {/* <select id='selectFilter' ref={(c) => this.selectFilter = c} multiple>
                    <option value='travel_mode'>Travel Mode</option>
                    <option value='claim_status'>Claim Status</option>
                </select> */}
                            <Form>
                                <Form.Control as="select" multiple onChange={this.onSelectedOptionsChange} ref={(c) => this.multiSelect = c}>
                                    {optionsMultiselect.map(options1 => (
                                        <option key={options1.name} value={options1.value}>
                                            {options1.name}
                                        </option>
                                    ))}
                                </Form.Control>
                            </Form>
                            {this.state.selectValues.map((selectedValue, index) => (
                                <span>
                                    <h5>{this.selectButtons[selectedValue].heading + " : "}</h5>
                                    <select key={index} ref={(c) => {
                                        this[selectedValue] = React.createRef();
                                        this[selectedValue] = c
                                    }}>
                                        {this.selectButtons[selectedValue].data.map((valueforoption) => (
                                            <option value={valueforoption.value}>{valueforoption.column}</option>
                                        ))}
                                    </select></span>
                            ))}
                        </div>))}
                    <div>
                        <button onClick={this.addGraph} className='btn-success'>Add Graph</button>
                    </div>
                    <div>
                        <button onClick={this.goButton}>Generate Graph</button>
                    </div>
                    {/* <div>
                <h4 style={{ color: "blue" }}> Total number of claims made per day in last 7 days</h4>
                <h4 style={{ color: "red" }}> Total number of claims pending per day in last 7 days</h4>
                <h4 style={{ color: "green" }}> Total number of claims approved per day in last 7 days</h4>
                <h4 style={{ color: "cyan" }}> Total number of claims made by two wheelers per day in last 7 days</h4>
                <h4 style={{ color: "yellow" }}> Total number of claims made by four wheelers per day in last 7 days</h4>
            </div> */}
                </div>
                <div style={{ width: '70%', float: "left" }}>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            </div>
        </div>
        );
    }
}
export default WithTimeCustom;