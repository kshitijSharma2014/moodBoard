import React from 'react';
import Home from './home/home'
import './App.css';
import OneValue from "./KPICharts/oneValue";
import withTimeCustom from './KPICharts/withTimeCustom';
import WithTimeCopy from './KPICharts/withTime copy';
import WithTimeCopy1 from './KPICharts/withTime copy 2';
import TotalClaim from './KPICharts/totalClaim';
import WithTimeCustom from './KPICharts/withTimeCustom';
import WithTimeCustomMulti from './KPICharts/withTimeCustomMulti';

class App extends React.Component {

  state = {
    kpiSelected: null,
  }

  handleKpiChange = (kpiSelected) => {
    this.setState(
      { kpiSelected }
    );
  }

  renderKPI = (kpiSelectedValue) => {
    if (kpiSelectedValue === 1) {
      return (
        <OneValue
          props={{
            heading: "Total JobCodes configured for Claims",
            data: "http://localhost:5500/data"
          }}></OneValue>
      )
    }
    else if (kpiSelectedValue === 1) {
      return (<TotalClaim
        props={{
          heading: "Total claims made in last 7 days",
          data: "http://localhost:5500/data"
        }}></TotalClaim>)
    }
    else if (kpiSelectedValue === 5) {
      return (<WithTimeCustom
        props={{
          heading: "Total claims made in last 7 days",
          data: "http://localhost:5500/data"
        }}></WithTimeCustom>)
    }
    else if (kpiSelectedValue === 6) {
      return (<WithTimeCopy
        props={{
          heading: "Total claims approved/pending in last 7 days",
          data: "http://localhost:5500/data"
        }}></WithTimeCopy>)
    }
    else if (kpiSelectedValue === 12) {
      return (<WithTimeCopy1
        props={{
          heading: "Total number of 2 wheeler Claims made till now",
          data: "http://localhost:5500/data"
        }}></WithTimeCopy1>)
    }
    else if (kpiSelectedValue === 14) {
      return (
        <OneValue
          props={{
            heading: "Total Distance travelled till now(K.M.)",
            data: "http://localhost:8086/kpi15"
          }}></OneValue>
      )
    }
    else if (kpiSelectedValue === 13) {
      return (
        <OneValue
          props={{
            heading: "Total amount of claim approved till now(Rs.)",
            data: "http://localhost:8086/kpi14"
          }}></OneValue>
      )
    }
    else if (kpiSelectedValue === 0) {
      return (
        <WithTimeCustomMulti
          props={{
            heading: "Total amount of claim approved till now(Rs.)",
            data: "http://localhost:8086/kpi14"
          }}></WithTimeCustomMulti>
      )
    }
    else {
      return (<div>
        <h2>KPI not configured</h2>
        <img alt="KPI not configured" src={require("./error-message.svg")} className="errorMsg" />
      </div>)
    }
  }

  render() {
    const { kpiSelected } = this.state;
    return (
      <div className="App">
        <Home
          handleKpiChange={this.handleKpiChange}
        />
        {kpiSelected !== null && <div id="homeKPI" className="homeKPI">
          {this.renderKPI(kpiSelected.value)}
        </div>}
      </div>
    );
  }
}

export default App;
