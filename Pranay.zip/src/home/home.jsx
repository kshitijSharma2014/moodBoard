import React, { Component } from 'react';
import Select from 'react-select';
import { KPIList } from "../kpiList";
import './home.css';

const customStyles = {
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
        return {
            ...styles,
            fontSize: '12px',
            textAlign: 'left',
        }
    },
};

class Home extends Component {

    optionBuilder = () => {
        let kpiList = new KPIList();
        const options = kpiList.kpiList.map((KPI, index) => {
            return {
                value: index,
                label: KPI
            }
        });
        return options;
    }

    render() {
        const { kpiSelected } = this.props;
        return (
            <div className="df fc">
                <div className="navHd">
                    <div className="header_title">KPI</div>
                    <img alt="jioLogo" src={require('./jioLogo.png')} className="jioLogoImg" />
                </div>
                <div className="" style={{ 'borderBottom': '1px solid lightgrey', 'padding': '10px' }}>
                    <div className="selectBoxContainer">
                        <Select
                            id="KPISelected"
                            noOptionsMessage={() => "KPI list is empty"}
                            value={kpiSelected}
                            onChange={this.props.handleKpiChange}
                            options={this.optionBuilder()}
                            placeholder='Select KPI'
                            styles={customStyles}
                        />
                    </div>
                </div>
            </div >
        )
    }
}

export default Home;