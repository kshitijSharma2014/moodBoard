# searchBox

Installation
1. npm install
2. npm run webpack
3. then open index.html in browser

demo: https://kshitijsharma2014.github.io/
