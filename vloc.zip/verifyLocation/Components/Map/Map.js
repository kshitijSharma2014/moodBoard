import React from "react";
import ReactDOM from "react-dom";
import { compose, withProps } from "recompose";
import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker
} from "react-google-maps";


const Map = compose(
  withProps({
    /**
     * Note: create and replace your own key in the Google console.
     * https://console.developers.google.com/apis/dashboard
     * The key "AIzaSyBkNaAGLEVq0YLQMi-PYEMabFeREadYe1Q" can be ONLY used in this sandbox (no forked).
     */
    googleMapURL:
      "https://maps.googleapis.com/maps/api/js?key=AIzaSyBzV9hl0JuWZM9jdg49s7-AwhqHPgzc_w8&v=3.exp&libraries=geometry,drawing,places",
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: `100%` }} />,
    mapElement: <div style={{ height: `100%` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props => (
  <div>
  <GoogleMap defaultZoom={6} defaultCenter={{ lat: props.lat, lng: props.lng }}>
    {props.isMarkerShown && ( 
      <Marker position={{ lat: props.lat, lng: props.lng }} />
    )}
  </GoogleMap>
  <img src="icons/marker.svg" onClick={props.setCurrentLocation} className="markerSvg pa" />
  </div>
));


export default Map;
