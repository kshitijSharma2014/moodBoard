export const layerDetails = [{
  id: "123-s2-546",
  name: "John Jacobs",
},
  {
    id: "123-s3-146",
    name: "David Mire",
  },
  {
    id: "223-a1-234",
    name: "Soloman Marshall",
  },
  {
    id: "121-s2-111",
    name: "Ricky Beno",
  },
  {
    id: "123-p2-246",
    name: "Sikander Singh",
  },
  {
    id: "b23-s2-321",
    name: "Ross Wheeler",
  },
  {
    id: "113-n2-563",
    name: "Ben Bish",
  },
  {
    id: "323-s2-112",
    name: "John Michael",
  },
  {
    id: "abc-34-122",
    name: "Jason Jordan",
  }
];