﻿var jId = "jID";
var jesaId = "jesaId";
var vehicleId = "vehicleId";
var esavehicleId = "esavehicleId";
var sapApId = "sapApId";

var rwaEditMode = false, rwaRowNumEdit, csRowNumEdit, csEditMode = false, rateRowNumEdit, rateEditMode = false, esaEditMode = false, esaRowNumEdit;

$('#newRWA').hide();
$('#newESA').hide();
$('#newRate').hide();


var waitForEl = function (selector, callback) {
    if (jQuery(selector).length) {
        callback();
    } else {
        setTimeout(function () {
            waitForEl(selector, callback);
        }, 100);
    }
};
var rwaTableCounter = 0;

var rateCardData = new Promise(function (resolve, reject) {
    $.ajax({
        url: '/ClaimManagementAccess/GetClaimRateData',
        success: function (data) {
            resolve(data);
        }
    });
});


function getVehicleNames(vehicles) {
    return vehicles.map(function (vehicle) {
        return vehicle.vehicletype
    }).join(',')
}


var rwlogTable = $('#rWLogTable').DataTable({
    "ajax": {
        url: "/ClaimManagementAccess/GetRoleMasterData/",
        cache: true,
    },
    "language": {
        "infoEmpty": "No records available - Got it?",
    },
    "paging": true, 
    "info": true,
    "retrieve": true,
    bSortable: true,
    bProcessing: true
});

var rwaOrderBy = 'ilastupdatedon';
var esaOrderBy = 'ilastupdatedon';

var rwaTable = $('#rWAListTable').DataTable({
    "ajax": {
        url: "/ClaimManagementAccess/GetRoleMasterData?orderBy="+ rwaOrderBy + "=order",
        cache: true,
    },
    "language": {
        "infoEmpty": "No records available.",
    },
    "paging": true,
    "info": true,
    "retrieve": true,
    "ordering": false,
    bSortable: false,
    bProcessing: true,
    "lengthChange": false,
    "bLengthChange": false,
    "columns": [
        {
            "data": "sr_no",
            "render": function (data, type, row, meta) {
                ++rwaTableCounter;
                return '<div>' + rwaTableCounter + '</div>';
            }
        },
        {
            "data": "ijobCode",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.ijobcode + ' class="jobIdSelect">'+row.ijobcode+'</div>';
            }
        },
        {
            "data": "ivehicletype",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.ivehicleid + '>' + row.ivehicletype + '</div>';
            }
        },
     
        {
            "data": "iperdiem",
            "render": function (data, type, row, meta) {
                return '<div>' + row.iperdiem + '</div>';
            }
        },
        {
            "data": "fromdate",
            "render": function (data, type, row, meta) {
                return '<div>' + row.fromdate + '</div>';
            }
        },
        {
            "data": "todate",
            "render": function (data, type, row, meta) {
                return '<div>' + row.todate + '</div>';
            }
        },
        {
            "data": "ilastupdatedon",
            "render": function (data, type, row, meta) {
                return '<div>' + row.ilastupdatedon + '</div>';
            }
        },
        {
            "data": "imodifiedby",
            "render": function (data, type, row, meta) {
                return '<div>' + row.imodifiedby + '</div>';
            }
        },
        {
            "render": function (data, type, row, meta) {
                return '<img src="/Areas/Admin/images/editRow.png" class="rwaEdit" style="width: 14px;cursor:pointer;" id=' + row.ijobcode + '/>' +
                        '<img src="/Areas/Admin/images/deleteRow.png" class="rwaDelete" style="width: 14px;margin-left: 10px; cursor:pointer;" id=' + row.ijobcode + '/>';
            }
        },
    ],
});
$('#rWAListTable').removeClass('form-inline dt-bootstrap no-footer dataTable');
$('#rWAListTable_wrapper').removeClass('dataTables_wrapper form-inline dt-bootstrap no-footer');

var rwaTableIDs = [];

rwaTable.on('search.dt', function () {
    //filtered rows data as arrays
    let searchInput = $('#rWAListTable_filter input').val() || "";
    if (searchInput.length === 0) {
        rwaTableIDs = [];
    }
    else {
        let tableData =  rwaTable.rows({ filter: 'applied' }).data();
        let length = tableData.length;
        rwaTableIDs = [];
        for (let i = 0; i < length; ++i) {
            rwaTableIDs.push(tableData[i].ijobcode)
        }
        console.log(rwaTableIDs);
    }
})

var empTableCounter=0;

var esaTable = $('#ESAListTable').DataTable({
    "ajax": {
        url:"/ClaimManagementAccess/GetEmpMasterData?orderBy="+esaOrderBy+"=order",
        cache: true,
    },
    "language": {
        "infoEmpty": "No records available - Got it?",
    },
    "paging": true,
    "info": true,
    "retrieve": true,
    "ordering": false,
    bSortable: false,
    bProcessing: true,
    "lengthChange": false,
    "bLengthChange": false,
    "columns": [
        {
            "data": "sr_no",
            "render": function (data, type, row, meta) {
                ++empTableCounter;
                return '<div>' + empTableCounter + '</div>';
            }
        },
        {
            "data": "employeeId",
            "render": function (data, type, row, meta) {
                return '<div>' + row.iemployeeid + '</div>';
            }
        },
        {
            "data": "ijobCode",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.ijobcode + ' class="jobIdSelect">' + row.ijobcode + '</div>';
            }
        },
        {
            "data": "ivehicletype",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.ivehicletype + ' >' + row.ivehicletype + '</div>';
            }
        },
        {
            "data": "perdiem",
            "render": function (data, type, row, meta) {
                return '<div>' + row.iperdiem + '</div>';
            }
        },
        {
            "data": "access",
            "render": function (data, type, row, meta) {
                return +row.iclaimaccess ? '<div>Yes</div>' : '<div>No</div>';
            }
        },
        {
            "data": "startDate",
            "render": function (data, type, row, meta) {
                return '<div>' + row.fromdate + '</div>';
            }
        },
        {
            "data": "endDate",
            "render": function (data, type, row, meta) {
                return '<div>' + row.todate + '</div>';
            }
        },
        {
            "data": "ilastupdatedon",
            "render": function (data, type, row, meta) {
                return '<div>' + row.ilastupdatedon + '</div>';
            }
        },
          {
              "data": "imodifiedby",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.imodifiedby + '</div>';
              }
          },
        {
            "render": function (data, type, row, meta) {
                return '<img src="/Areas/Admin/images/editRow.png" class="esaEdit" style="width: 14px;cursor:pointer;" id=' + row.iemployeeid + '/>' +
                    '<img src="/Areas/Admin/images/deleteRow.png" class="esaDelete" style="width: 14px;margin-left: 10px;cursor:pointer;" id=' + row.iemployeeid + '/>';
            }
        },
    ]
});
$('#ESAListTable').removeClass('form-inline dt-bootstrap no-footer dataTable');
$('#ESAListTable_wrapper').removeClass('dataTables_wrapper form-inline dt-bootstrap no-footer');

function onChangeRwaSort(e) {
    let value = e.target.value;
    rwaOrderBy = value;
    rwaTable.ajax.url("/ClaimManagementAccess/GetRoleMasterData?orderBy=" + rwaOrderBy + "=order").load()
}

function onChangeEsaSort(e) {
    let value = e.target.value;
    esaOrderBy = value;
    esaTable.ajax.url("/ClaimManagementAccess/GetEmpMasterData?orderBy=" + esaOrderBy + "=order").load()
}

var esaTableIDs = [];

esaTable.on('search.dt', function () {
    //filtered rows data as arrays
    let searchInput = $('#ESAListTable_filter input').val() || "";
    if (searchInput.length === 0) {
        esaTableIDs = [];
    }
    else {
        let tableData = esaTable.rows({ filter: 'applied' }).data();
        let length = tableData.length;
        esaTableIDs = [];
        for (let i = 0; i < length; ++i) {
            esaTableIDs.push(tableData[i].iemployeeid)
        }
        console.log(esaTableIDs);
    }
})

var rateCardCount = 0;

var rateCardTable = $('#rateCardTable').DataTable({
    "ajax": '/ClaimManagementAccess/GetClaimRateData',
    "paging": false,
    "info": false,
    "retrieve": true,
    bSortable: true,
    bProcessing: true,
    "searching": false,
    "columns": [
        {
            "data": "sr_no",
            "render": function (data, type, row, meta) {
                ++rateCardCount;
                return '<div>' + rateCardCount + '</div>';
            }
        },
         {
             "data": "vehicletype",
             "render": function (data, type, row, meta) {
                 return '<div id = ' + row.vehicleid + '>' + row.vehicletype + '</div>';
             }
         },
          {
              "data": "perkmrate",
              "render": function (data, type, row, meta) {
                  return '<div>' + data + '</div>';
              }
          },
           {
               "data": "lastupdatedon",
               "render": function (data, type, row, meta) {
                  
                   return '<div>' + data + '</div>';
               }
           },
           {
               "data": "imodifiedby",
               "render": function (data, type, row, meta) {
                   return '<div>' + row.imodifiedby + '</div>';
               }
           },
           {
               "render": function (data, type, row, meta) {
                   return '<img src="/Areas/Admin/images/editRow.png" class="rateEdit" style="width: 14px;cursor:pointer;" id=' + row.ivehicleid + '/>';
               }
           },
    ]
});



$('#rateCardTable').removeClass('form-inline dt-bootstrap no-footer dataTable');
$('#rateCardTable_wrapper').removeClass('dataTables_wrapper form-inline dt-bootstrap no-footer');



var CSTableCounter = 0;
var clientSapTable = $('#clientSapTable').DataTable({
    "ajax": "/ClaimManagementAccess/GetClientSAPAPIData",
    "paging": false,
    "searching": false,
    "info": false,
    "retrieve": true,
    bProcessing: true,
    bSortable: true,
    "columns": [
        {
            "render": function (data, type, row, meta) {
                ++CSTableCounter;
                return '<div>' + CSTableCounter + '</div>';
            }
        },
         {
             "data": "iclientid",
             "render": function (data, type, row, meta) {
                 return '<div>' + row.iclientid + '</div>';
             }
         },
          {
              "data": "isapapiid",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.isapapiid + '</div>';
              }
          },
          {
              "data": "iappserverhost",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.iappserverhost + '</div>';
              }
          },
          {
              "data": "isystemno",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.isystemno + '</div>';
              }
          },
          {
              "data": "iusername",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.iusername + '</div>';
              }
          },
          {
              "data": "ipswd",
              "render": function (data, type, row, meta) {
                  return '<div>' + '******' + '</div>';
              }
          },
          {
              "data": "iname",
              "render": function (data, type, row, meta) {
                  return '<div>' + row.iname + '</div>';
              }
          },
           {
               "data": "ilastupdatedon",
               "render": function (data, type, row, meta) {

                   return '<div>' + row.ilastupdatedon + '</div>';
               }
           },
           {
               "data": "imodifiedby",
               "render": function (data, type, row, meta) {
                   return '<div>' + row.imodifiedby + '</div>';
               }
           },
           {
               "render": function (data, type, row, meta) {
                   return '<img src="/Areas/Admin/images/editRow.png" class="csEdit" style="width: 14px;cursor:pointer;" id=' + row.iclientid + '/>' +
                            '<img src="/Areas/Admin/images/deleteRow.png" class="csDelete" style="width: 14px;margin-left: 10px;cursor:pointer;" id=' + row.iclientid + '/>';
               }
           },
    ]
});



$('#clientSapTable').removeClass('form-inline dt-bootstrap no-footer dataTable');
$('#clientSapTable_wrapper').removeClass('dataTables_wrapper form-inline dt-bootstrap no-footer');

function IDGenerator() {
	 
    this.length = 8;
    this.timestamp = +new Date;
		 
    var _getRandomInt = function( min, max ) {
        return Math.floor( Math.random() * ( max - min + 1 ) ) + min;
    }
		 
    this.generate = function() {
        var ts = this.timestamp.toString();
        var parts = ts.split( "" ).reverse();
        var id = "";
			 
        for( var i = 0; i < this.length; ++i ) {
            var index = _getRandomInt( 0, parts.length - 1 );
            id += parts[index];	 
        }
			 
        return id;
    }

		 
}

var generator = new IDGenerator();

    $('#rwaAdd').on('click', function () {
        var data;
        $('#newRWA').show();
        dragElement(document.getElementById("newRWA"));
      
        setDateTimeCalendarClaimRwa();
        $('#addvehicleType').chosen();
        $('#addvehicleType').empty();
        rateCardData.then(function (data) {
            data.data.map(function (item) {
                $('#addvehicleType').append('<option value=' + item.vehicleid + '>' + item.vehicletype + '</option>');
            });
            $("#addvehicleType").trigger("chosen:updated");
        });
            $('#addRoleId').chosen();
            $('#addRoleId').empty();

        $.ajax({
            url: "/ClaimManagementAccess/GetJobCodeJSON",
            dataType: "json",
        }).done(function (data) {
            data.jobcodes.map(function (item) {
                $('#addRoleId').append('<option value=' + item.jobcode + '>' + item.jobcode + '</option>');
            });
            $('#addRoleId').prop('disabled', false);
            $("#addRoleId").trigger("chosen:updated");
        });
        $(document).on("click", function (e) {
            var container = $("#addRoleId");

            if (!container.is(e.target) && container.has(e.target).length === 0) {
                container.trigger('chosen:close');
            }
        });
    });

    $('#esaAdd').on('click', function () {

        $('#newESA').show();
        setDateTimeCalendarClaimEmp()
        dragElement(document.getElementById("newESA"));
        $('#addvehicleTypeEsa').chosen();
        $('#addvehicleTypeEsa').empty();



        $.ajax({
            url: "/ClaimManagementAccess/GetClaimRateData",
            dataType: "json",
        }).done(function (data) {
            data.data.map(function (item) {
                $('#addvehicleTypeEsa').append('<option value=' + item.vehicleid + '>' + item.vehicletype + '</option>');
            });
            $("#addvehicleTypeEsa").trigger("chosen:updated");
        });
       
        var selectedEmp = [];
        $('#addEmpIdEsa').on("input", SearchEmpSolr);
    });

    $('#rateAdd').on('click', function () {
        var data;
        $('#newRate').show();
        dragElement(document.getElementById("newRate"));
        
        $.ajax({
            url: "/ClaimManagementAccess/GetVehiTypeJSON?edit=0",
            dataType: "json",
        }).done(function (data) {
            data.vehicleTypes.map(function (item) {
                $('#newVehicleType').append('<option value=' + item + '>' + item + '</option>');
            });
            $('#newVehicleType').prop('disabled', false);
            $("#newVehicleType").trigger("chosen:updated");
        });
        
    });

    $('#CSadd').on('click', function () {
        var data;
        $('#newCS').show();
        dragElement(document.getElementById("newCS"));

        $('#newClientId').chosen();
        $('#newClientId').empty();

        $.ajax({
            url: "/ClaimManagementAccess/GetClientIDJSON?edit=0",
            dataType: "json",
        }).done(function (data) {
            data.clientids.map(function (item) {
                $('#newClientId').append('<option value=' + item.clientid + '>' + item.clientid + '</option>');
            });
            $('#newClientId').prop('disabled', false);
            $("#newClientId").trigger("chosen:updated");
        });
    });


    function checkZero(data) {
        if (data.length == 1) {
            data = "0" + data;
        }
        return data;
    }

    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

    function formatDate(todayDate) {
        var today = new Date(todayDate);
        var day = today.getDate() + "";
        var month = (today.getMonth() + 1) + "";
        var year = today.getFullYear() + "";
        var hour = today.getHours() + "";
        var minutes = today.getMinutes() + "";
        var seconds = today.getSeconds() + "";

        day = checkZero(day);
        year = checkZero(year);
        hour = checkZero(hour);
        mintues = checkZero(minutes);
        seconds = checkZero(seconds);

        return day + "-" + months[month - 1] + "-" + year + " " + hour + ":" + minutes + ":" + seconds;
    }

    function unFormatDate(date) {
        var dateValAr = date.split(' ')[0];
        var dateAr = dateValAr.split('-');
        var dateVal = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0] + ' ' + dateValAr[1];
       return new Date(dateVal);
    }


    function rwaAdd() {
        var selectedRoles = $("#addRoleId").val();
        var vehicleId = $("#addvehicleType").val();
        var iperdiem = $("#rwaPerdiem").val().toString();
        var fromdate = formatDate($('#addStartDate').val());
        var todate = formatDate($('#addEndDate').val());
        var ilastupdatedon = formatDate(new Date(Date.now()));
        var datatableData = [];
        let dateToday = new Date();
        let selectedVehicles, vehicletype;
        if (new Date(fromdate) > new Date(todate)) {
            alert("start date cannot be ahead of end date");
            return;
        } else if (new Date(fromdate) < new Date(dateToday.toDateString()) && !rwaEditMode) {
            alert("start date cannot be before today's date");
            return;
        }

        if (iperdiem === "" || $('#addStartDate').val() === "" || $('#addEndDate').val() === "") {
            alert("Please fill all fields");
            return;
        }

        rateCardData.then(function (data) {
            selectedVehicles = data.data.filter(function (value) {
                return value.vehicleid === vehicleId;
            });
            vehicletype = getVehicleNames(selectedVehicles);
            selectedRoles.map(function (selectedRole) {
                datatableData.push({
                    ijobcode: selectedRole,
                    ivehicleid: vehicleId,
                    iperdiem: iperdiem,
                    fromdate: fromdate,
                    todate: todate,
                    ilastupdatedon: ilastupdatedon,
                    ivehicletype: vehicletype,
                });
            });

            $.ajax({
                type: "POST",
                url: '/ClaimManagementAccess/UpdateRoleClaimAccess',
                data: { 'roledata': datatableData },
                'Content-Type': 'application/json; charset=utf-8',
                async: false,
                success: function (response) {
                    if (rwaEditMode)
                    {
                       // rwaTable.row(rwaRowNumEdit).data(datatableData[0]).draw()
                        rwaEditMode = false;
                        rwaTableCounter = 0;
                        rwaTable.ajax.reload();
                    }
                    else {
                        /*for (let i = 0; i < datatableData.length; ++i) {
                            rwaTable.row.add(datatableData[i]).draw(false);

                        }*/
                        rwaTableCounter = 0;
                        rwaTable.ajax.reload();
                    }
                    $("#addRoleId").prop('disabled', false);
                    closeRwaModal();
                }
            });
        });
               
    };

    function setDateTimeCalendarClaimEmp() {
        //calendar.refresh();
        Calendar.setup({
            inputField: "addStartDateEsa",   // id of the input field
            ifFormat: "%d-%b-%Y",       // format of the input field
            weekNumbers: false,
            //onClose: bindRetailersOnDateChange,
            // onUpdate: catcalc,
            //disableFunc: function (date) {
            //    var now = new Date();
            //    if (date.getTime() < now.getTime()) {
            //        return true;
            //    }

            //}
        });
        Calendar.setup({
            inputField: "addEndDateEsa",
            ifFormat: "%d-%b-%Y",
            weekNumbers: false,
            align: "Br",
            // onClose: bindRetailersOnDateChange,
            // onUpdate: catcalc,
            //disableFunc: function (date) {
            //    var startdt = new Date(document.getElementById("startdate").value);

            //    if (date.getTime() < startdt.getTime()) {
            //        return true;
            //    }

            //}
        });
    }


    function setDateTimeCalendarClaimRwa() {
        //calendar.refresh();
        Calendar.setup({
            inputField: "addStartDate",   // id of the input field
            ifFormat: "%d-%b-%Y",       // format of the input field
            weekNumbers: false,
            //onClose: bindRetailersOnDateChange,
            // onUpdate: catcalc,
            //disableFunc: function (date) {
            //    var now = new Date();
            //    if (date.getTime() < now.getTime()) {
            //        return true;
            //    }

            //}
        });
        Calendar.setup({
            inputField: "addEndDate",
            ifFormat: "%d-%b-%Y",
            weekNumbers: false,
            align: "Br",
            // onClose: bindRetailersOnDateChange,
            // onUpdate: catcalc,
            //disableFunc: function (date) {
            //    var startdt = new Date(document.getElementById("startdate").value);

            //    if (date.getTime() < startdt.getTime()) {
            //        return true;
            //    }

            //}
        });
    }




    function ESAaddRow() {

        var selectedEmp = $("#addEmpIdEsa").val();
        var fromdate = formatDate($('#addStartDateEsa').val());
        var iperdiem = $("#esaPerdiem").val().toString();
        var todate = formatDate($('#addEndDateEsa').val());
        
        var datatableData = [];
        var vehicleId = $("#addvehicleTypeEsa").val();
        var ilastupdatedon = formatDate(new Date(Date.now()));
        var datatableData = [];
        let dateToday = new Date();
        let selectedVehicles, vehicletype;
        if (new Date(fromdate) > new Date(todate)) {
            alert("start date cannot be ahead of end date");
            return;
        } else if (new Date(fromdate) < new Date(dateToday.toDateString()) && !esaEditMode) {
            alert("start date cannot be before today's date");
            return;
        }

        if (iperdiem === "" || $('#addStartDateEsa').val() === "" || $('#addEndDateEsa').val() === "") {
            alert("Please fill all fields");
            return;
        }
        rateCardData.then(function (data) {
            selectedVehicles = data.data.filter(function (value) {
                return value.vehicleid === vehicleId;
            });
            vehicletype = getVehicleNames(selectedVehicles);
                datatableData.push({
                    iemployeeid: selectedEmp,
                    ijobcode: '',
                    ivehicleid: vehicleId,
                    iperdiem: iperdiem,
                    fromdate: fromdate,
                    todate: todate,
                    ilastupdatedon: ilastupdatedon,
                    ivehicletype: vehicletype,
                    iclaimaccess: $("input[name='addESAaccess']:checked").val() === "yes" ? 1 : 0,
                });                
      
        $.ajax({
            type: "POST",
            url: '/ClaimManagementAccess/UpdateEmpClaimAccess',
            data: { 'empdata': datatableData },
            'Content-Type': 'application/json; charset=utf-8',
            async: false,
            success: function (data) {
                if (esaEditMode) {
                    // rwaTable.row(rwaRowNumEdit).data(datatableData[0]).draw()
                    esaEditMode = false;
                    empTableCounter = 0;
                    esaTable.ajax.reload();
                }
                else {
                    empTableCounter = 0;
                    esaTable.ajax.reload();

                   /* for (let i = 0; i < datatableData.length; ++i) {
                        esaTable.row.add(datatableData[i]).draw(false);
                    }*/

                }
             }
        });
        });
        closeEsaModal();
    }

    function rateaddRow() {
        var vehicleType = $('#newVehicleType').val();
        var perKmRate = $('#perKmRate').val();
        var data = [];
        
        if (rateEditMode) {
            data = [
                {
                    vehicletype: vehicleType,
                    perkmrate: perKmRate,
                    lastupdatedon: formatDate(new Date(Date.now())),
                    vehicleid: $('#newVehicleType').attr('data-id'),
                }
            ];
        }
        else {
            data = [{
                vehicletype: vehicleType,
                perkmrate: perKmRate,
                lastupdatedon: formatDate(new Date(Date.now())),
                vehicleid: generator.generate(),
            }];
        }
        
        $.ajax({
            type: "POST",
            url: '/ClaimManagementAccess/UpdateRateCardData',
            data: { ratedata: data },
            'Content-Type': 'application/json; charset=utf-8',
            async: false,
            success: function (response) {
                if (rateEditMode) {
                    //rateCardTable.row(rateRowNumEdit).data(data[0]).draw();
                    rateEditMode = false;
                    rateCardCount = 0;
                    rateCardTable.ajax.reload();
                }
                else {
                    rateCardCount = 0;
                    rateCardTable.ajax.reload();
                   // rateCardTable.row.add(data[0]).draw(false);

                }
                $("#newVehicleType").prop('disabled', false);
                closeRateModal();
            }
        });
    
    };

    function CsaddRow() {
        var iclientid = $('#newClientId').val();
        var isapapiid = $('#newSapApiId').val();
        var iappserverhost = $('#newAppServerHost').val();
        var isysno = $('#newSysNo').val();
        var iusername = $('#newUserName').val();
        var ipswd = $('#newPassword').val();
        var iname = $('#newName').val();
        var data = [];
            data.push({
                iclientid: iclientid,
                isapapiid: isapapiid,
                iappserverhost: iappserverhost,
                isystemno: isysno,
                iusername: iusername,
                ipswd: ipswd,
                iname: iname,
                ilastupdatedon: formatDate(new Date(Date.now())),
        });
        $.ajax({
            type: "POST",
            url: '/ClaimManagementAccess/UpdateCSData',
            data: { csdata: data },
            'Content-Type': 'application/json; charset=utf-8',
            async: false,
            success: function (responnse) {
                if (csEditMode) {
                    //clientSapTable.row(rwaRowNumEdit).data(data[0]).draw()
                    csEditMode = false;
                    CSTableCounter = 0;
                    clientSapTable.ajax.reload();
                }
                else {
                    /*for (var i = 0; i < data.length; ++i) {
                        clientSapTable.row.add(data[i]).draw(false);
                    }*/
                    CSTableCounter = 0;
                    clientSapTable.ajax.reload();
                }
                closeCSModal();
            }
        });
    }

    function onEmpIdClick(e) {
        var empId = e.target.id;
        $('#addEmpIdEsa').val(empId);
        $('#empList').hide();
        $('#empList').empty();

    }

    function SearchEmpSolr(e) {
        var queryParam = e.target.value;
        if (queryParam.length === 0) {
            $('#empList').hide();
            $('#empList').empty();
        }
        if (queryParam.length > 2) {
            var drpItems = [];
           /* $("#addEmpIdEsa").empty().append($('< option>'))
            $("#addEmpIdEsa").trigger("chosen:updated");*/
            $.ajax({
                type: "GET",
                url: '/ClaimManagementAccess/hotSpotSearch?srchTxt=' + queryParam,
                'Content-Type': 'application/html; charset=utf-8',
                success: function (responnse) {

                    let data = JSON.parse(responnse).response.docs || [];
                    if(data.length === 0) {
                        $('#empList').hide();
                    } else {
                        $('#empList').show();
                    }
                    
                    $('#empList').empty();
                    data.map(function (item) {

                        $('#empList').append('<div onclick="onEmpIdClick(event)" id=' + item.employeeid + ' class="employeeId" value=' + item.employeeid + '>' + item.employeeid + '</div>');
                    });
                }
            });

            $("#addEmpIdEsa").val()
        }
       
    }    
    $('#rWAListTable').on('click', 'tbody .rwaDelete', function () {
        var data_row = rwaTable.row($(this).closest('tr')).data();
        if (data_row.ijobcode != null && data_row.ijobcode != '') {
            if (window.confirm("Are you sure you want to remove jobcode '"+ data_row.ijobcode + "'?")) {
                $.ajax({
                    type: "POST",
                    url: '/ClaimManagementAccess/DeleteRowClaimAccess',
                    data: { 'roleempid': data_row.ijobcode, 'type': 0 },
                    'Content-Type': 'application/json; charset=utf-8',
                    async: false,
                    success: function (response) {
                        rwaTableCounter = 0;
                        rwaTable.ajax.reload();
                    }
                });
            }

        }
    });

    $('#ESAListTable').on('click', 'tbody .esaDelete', function () {
        var data_row = esaTable.row($(this).closest('tr')).data();
        if (data_row.iemployeeid != null && data_row.iemployeeid != '') {
            if (window.confirm("Are you sure you want to remove employee '" + data_row.iemployeeid + "'?")) {
                $.ajax({
                    type: "POST",
                    url: '/ClaimManagementAccess/DeleteRowClaimAccess',
                    data: { 'roleempid': data_row.iemployeeid, 'type': 1 },
                    'Content-Type': 'application/json; charset=utf-8',
                    async: false,
                    success: function (response) {
                        empTableCounter = 0;
                        esaTable.ajax.reload();
                    }
                });
            }

        }
    });
    $('#rateCardTable').on('click', 'tbody .rateDelete', function () {
        var data_row = rateCardTable.row($(this).closest('tr')).data();
        if (data_row.vehicleid != null && data_row.vehicleid != '') {
            if (window.confirm("Are you sure you want to remove '" + data_row.vehicletype + "'?")) {
                $.ajax({
                    type: "POST",
                    url: '/ClaimManagementAccess/DeleteRowClaimAccess',
                    data: { 'roleempid': data_row.vehicleid, 'type': 2 },
                    'Content-Type': 'application/json; charset=utf-8',
                    async: false,
                    success: function (response) {
                        rateCardCounter = 0;
                        rateCardTable.ajax.reload();
                    }
                });
            }

        }
    });
    $('#clientSapTable').on('click', 'tbody .csDelete', function () {
        var data_row = clientSapTable.row($(this).closest('tr')).data();
        if (data_row.iclientid != null && data_row.iclientid != '') {
            if (window.confirm("Are you sure you want to remove clientid '" + data_row.iclientid + "'?")) {
                $.ajax({
                    type: "POST",
                    url: '/ClaimManagementAccess/DeleteRowClaimAccess',
                    data: { 'roleempid': data_row.iclientid, 'type': 3 },
                    'Content-Type': 'application/json; charset=utf-8',
                    async: false,
                    success: function (response) {
                        CSTableCounter = 0;
                        clientSapTable.ajax.reload();
                    }
                });
            }

        }
    });
    $('#rWAListTable').on('click', 'tbody .rwaEdit', function () {
        var data_row = rwaTable.row($(this).closest('tr')).data();
        rwaEditMode = true;
        $("#newRWA").show();
        setDateTimeCalendarClaimRwa();
        $('#addStartDate').val(data_row.fromdate);

        $('#addEndDate').val(data_row.todate);

        $('#rwaPerdiem').val(data_row.iperdiem);

        $('#addvehicleType').chosen();
        $('#addvehicleType').empty();
        rateCardData.then(function (data) {
            data.data.map(function (item) {
                $('#addvehicleType').append('<option value=' + item.vehicleid + '>' + item.vehicletype + '</option>');
            });
            $("#addvehicleType").val(data_row.ivehicleid);
            $("#addvehicleType").trigger("chosen:updated");
        });
        $('#addRoleId').chosen();
        $('#addRoleId').empty();

        $.ajax({
            url: "/ClaimManagementAccess/GetJobCodeJSON",
            dataType: "json",
        }).done(function (data) {
            data.jobcodes.map(function (item) {
                $('#addRoleId').append('<option value=' + item.jobcode + '>' + item.jobcode + '</option>');
            });
            $("#addRoleId").val(data_row.ijobcode);
            $('#addRoleId').prop('disabled', true);
            $("#addRoleId").trigger("chosen:updated");

        });
        $(document).on("click", function (e) {
            var container = $("#addRoleId");

            if (!container.is(e.target) && container.has(e.target).length === 0) {
                container.trigger('chosen:close');
            }
        });

        rwaRowNumEdit = rwaTable.row($(this).closest('tr'))[0][0];
    });

    $('#ESAListTable').on('click', 'tbody .esaEdit', function () {
        var data_row = esaTable.row($(this).closest('tr')).data();
        setDateTimeCalendarClaimEmp();
        esaEditMode = true;
        $("#newESA").show();
        $('#addvehicleTypeEsa').chosen();

        $('#addStartDateEsa').val(data_row.fromdate);

        $('#addEndDateEsa').val(data_row.todate);

      

        $('#esaPerdiem').val(data_row.iperdiem);
        var radioVal = data_row.iclaimaccess === 0 ? "no" : "yes";
        $("input[name=addESAaccess][value=" + radioVal + "]").prop('checked', true);

        //$('#addvehicleTypeEsa').chosen();
        //$('#addvehicleTypeEsa').empty();
        rateCardData.then(function (data) {
            data.data.map(function (item) {
                $('#addvehicleTypeEsa').append('<option value=' + item.vehicleid + '>' + item.vehicletype + '</option>');
            });
            $("#addvehicleTypeEsa").val(data_row.ivehicleid);
            $("#addvehicleTypeEsa").trigger("chosen:updated");
        });


        $("#addEmpIdEsa").val(data_row.iemployeeid);
        $('#addEmpIdEsa').prop('disabled', true);
        
        esaRowNumEdit = esaTable.row($(this).closest('tr'))[0][0];
    });

    $('#clientSapTable').on('click', 'tbody .csEdit', function () {
        csEditMode = true;
        var data_row = clientSapTable.row($(this).closest('tr')).data();
        rwaEditMode = true;
        $("#newCS").show();

        $('#newClientId').chosen();
        //$('#newClientId').empty();

        $.ajax({
            url: "/ClaimManagementAccess/GetClientIDJSON?edit=1",
            dataType: "json",
        }).done(function (data) {
            data.clientids.map(function (item) {
                $('#newClientId').append('<option value=' + item.clientid + '>' + item.clientid + '</option>');
            });
            $("#newClientId").val(data_row.iclientid);
            $('#newClientId').prop('disabled', true);
            $("#newClientId").trigger("chosen:updated");
        });
        $('#newSapApiId').val(data_row.isapapiid);
        $('#newAppServerHost').val(data_row.iappserverhost);
        $('#newSysNo').val(data_row.isystemno);
        $('#newUserName').val(data_row.iusername);
        $('#newPassword').val(data_row.ipswd);
        $('#newName').val(data_row.iname);
      //  csRowNumEdit = clientSapTable.row($(this).closest('tr'))[0][0];
    });

    $('#rateCardTable').on('click', 'tbody .rateEdit', function () {
        csEditMode = true;
        var data_row = rateCardTable.row($(this).closest('tr')).data();
        rateEditMode = true;
        $("#newRate").show();
        $('#newVehicleType').val(data_row.vehicletype);
        $("#newVehicleType").prop('disabled', true);
        $('#newVehicleType').attr('data-id', data_row.vehicleid)
        $('#perKmRate').val(data_row.perkmrate);
        rateRowNumEdit = rateCardTable.row($(this).closest('tr'))[0][0];
        
        $.ajax({
            url: "/ClaimManagementAccess/GetClientIDJSON?edit=1",
            dataType: "json",
        }).done(function (data) {
            data.clientids.map(function (item) {
                $('#newClientId').append('<option value=' + item.clientid + '>' + item.clientid + '</option>');
            });
            $("#newClientId").val(data_row.iclientid);
            $('#newClientId').prop('disabled', true);
            $("#newClientId").trigger("chosen:updated");
        });
        $('#newSapApiId').val(data_row.isapapiid);
    });

    function closeCSModal() {
        $("#newVehicleType").prop('disabled', false);
        $('#newClientId').val('');
        $('#newSapApiId').val('');

        $('#newClientId').chosen();
        $('#newClientId').empty();

        $('#newAppServerHost').val('');
        $('#newSysNo').val('');
        $('#newUserName').val('');
        $('#newPassword').val('');
        $('#newName').val('');
        $('#newCS').hide();
    }

    function closeRateModal() {
        $("#newVehicleType").prop('disabled', false);
        $('#newVehicleType').val('');
        $('#perKmRate').val('');
        $('#newRate').hide();
      }

    function closeRwaModal() {
//        $("#newVehicleType").prop('disabled', false);
        $('#addvehicleType').val('');
        $('#rwaPerdiem').val('');
        $('#newRWA').hide();
        $('#addRoleId').chosen('destroy');
        $('#addvehicleType').chosen('destroy');
    }

    function closeEsaModal() {
        $('#addvehicleTypeEsa').val('');
        $('#esaPerdiem').val('');
        $('#addEmpIdEsa').val('');
        $('#addvehicleTypeEsa').empty();
        $('#empList').empty();
        $("#addEmpIdEsa").prop('disabled', false);
        $('#addStartDateEsa').val("");
        $('#addEndDateEsa').val("");
        $('#empList').hide();
        $('#addvehicleTypeEsa').chosen('destroy');
        $('#newESA').hide();

    }

    function getData(table) {
        var data = table.rows().data();
        delete data.context;
        //delete data.length;   // Do not delete this one! Needed for the loop below.
        delete data.selector;
        delete data.ajax;

        console.log(JSON.stringify(data));

        // Make the resulting "striped" object an array.
        var dataAsArray = [];
        console.log(data.length);

        for (i = 0; i < data.length; i++) {
            dataAsArray.push(data[i]);
        }
        return dataAsArray;
    }

    function tableExport(tabType) {
        debugger;
        let ids1 = tabType === 1 ? rwaTableIDs : esaTableIDs
       var ids= ids1.join(',');

        var iframe = $('<iframe>', {
            width: 1,
            height: 1,
            frameborder: 0,
            css: {
                display: 'none'
            }
        }).appendTo('body');

        var formHTML = '<form action="" method="post">' +
            '<input type="hidden" name="filename" />' +
            '<input type="hidden" name="ids" />' +
            '<input type="hidden" name="tabType" />' +          
            '</form>';

        // Giving IE a chance to build the DOM in
        // the iframe with a short timeout:
        script = "ExportDataP";
        var filename = "";
        setTimeout(function () {
            // The body element of the iframe document:
            var body = (iframe.prop('contentDocument') !== undefined) ? iframe.prop('contentDocument').body : iframe.prop('document').body; // IE
            body = $(body);
            // Adding the form to the body:
            body.html(formHTML);
            var form = body.find('form');
            form.attr('action', script);
            form.find('input[name=filename]').val(filename);
            form.find('input[name=ids]').val(ids);
            form.find('input[name=tabType]').val(tabType);           
            // Submitting the form to download.php. This will
            // cause the file download dialog box to appear.
            form.submit();
        }, 50);


        //let ids = tabType === 1 ? rwaTableIDs : esaTableIDs
        //$.ajax({
        //    url: "/ClaimManagementAccess/ExportDataP?TabType=" + tabType,
        //    type: 'post',
        //    contentType: 'application/x-www-form-urlencoded',
        //    data: { ids: ids.join(',') }
        //}).done(function (data) {

        //});
    }

    function GetClaimDataLogs(pagenumber) {

        var userid = $("#ClaimLogtxtEmpJobId").val();
        var fromDate = $("#JbpLogtxtFromDate").val();
        var todate = $("#JbpLogtxtToDate").val();

        //if ($('#ddlLogTables').val() == "") {
        //    alert("Please Select Table Name!");
        //    return false;
        //}

        //if ($.trim(userid) == '') {
        //    $('#dvContainer').html('');
        //    alert('Please Enter Employee ID/Name ');
        //    return false;
        //}

        //if ($.trim(userid).length <= 3) {
        //    $('#dvContainer').html('');
        //    alert('Please Enter at least four letter of Employee ID/Name ');
        //    return false;
        //}

        if ($.trim(fromDate) == '') {
            $('#dvContainer').html('');
            alert('Please Select From Date ');
            return false;
        }
        if ($.trim(todate) == '') {
            $('#dvContainer').html('');
            alert('Please Select To Date ');
            return false;
        }

        var From_date = toDate("#JbpLogtxtFromDate");
        var To_date = toDate("#JbpLogtxtToDate");

        if (To_date < From_date) {
            alert("End date time can not be less than Start date time!");
            return false;
        }
        var claimType = 1;
        if ($('#rdbClaimJobCode').prop('checked') == true) {
            claimType = 0;
        }

        var selDate = $('#ddlLogTables option:selected').text();
        var selMonth = selDate.split(' ')[0];
        var selYear = selDate.split(' ')[1];

        var finalMonth;
        var tableName = '';
        switch (selMonth) {
            case "JAN":
                finalMonth = 1;
                tableName = "01" + selYear;
                break;
            case "FEB": finalMonth = 2;
                tableName = "02" + selYear;
                break;
            case "MAR": finalMonth = 3;
                tableName = "03" + selYear;
                break;
            case "APR": finalMonth = 4;
                tableName = "04" + selYear;
                break;
            case "MAY": finalMonth = 5;
                tableName = "05" + selYear;
                break;
            case "JUN": finalMonth = 6;
                tableName = "06" + selYear;
                break;
            case "JUL": finalMonth = 7;
                tableName = "07" + selYear;
                break;
            case "AUG": finalMonth = 8;
                tableName = "08" + selYear;
                break;
            case "SEP": finalMonth = 9;
                tableName = "09" + selYear;
                break;
            case "OCT": finalMonth = 10;
                tableName = "10" + selYear;
                break;
            case "NOV": finalMonth = 11;
                tableName = "11" + selYear;
                break;
            case "DEC": finalMonth = 12;
                tableName = "12" + selYear;
                break;
        }
        var fromD = toDate("#JbpLogtxtFromDate");
        var fromMonth = fromD.getMonth() + 1;
        var fromYear = fromD.getFullYear();

        var toD = toDate("#JbpLogtxtToDate");
        var toMonth = toD.getMonth() + 1;
        var toYear = toD.getFullYear();

        //if ((selYear != fromYear) || (selYear != toYear))
        //{
        //    alert("Year should be same as per Selected table!");
        //    return false;
        //}
        //if ((finalMonth != fromMonth) || (finalMonth != toMonth)) {
        //    alert("Month should be same as per Selected table!");
        //    return false;
        //}
        //AjaxRequest('RecordSearch/GetJioBeatLogs', { 'userid': userid, 'fromDate': fromDate, 'todate': todate }, !0, function (data) {
        //    //$('#dvContainer').html('');
        //    //$('#dvContainer').html(data);

        //    //if (data.split('No Record').length > 1) {
        //    //    $('#lnkExport').hide();
        //    //}
        //});
        if (pagenumber == '')
            pagenumber = 1;

        var urls = $("#GetClaimLogurl").val();
        ShowLoader();
        $.ajax({
            url: urls,
            dataType: 'text',
            type: 'post',
            contentType: 'application/x-www-form-urlencoded',
            data: ({ 'userid': userid, 'fromDate': fromDate, 'todate': todate, 'claimType': claimType, 'pagenumber': pagenumber }),
            success: function (data, textStatus, jQxhr) {
                $('#dvContainer').html('');
                $('#dvContainer').html(data);
                HideLoader();
                if (pagenumber > 1)
                { $('#dvPaging a').removeClass('selectedpage'); $('#dvPaging a').removeClass('allotherpage'); }
                $('#page_' + pagenumber).addClass('selectedpage');
                $('#lnkExportCP').show();
            },
            error: function (jqXhr, textStatus, errorThrown) {
                //console.log(errorThrown);
                HideLoader();
            }
        });

    }


    // Make the DIV element draggable:
    function dragElement(elmnt) {
        var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        if (document.getElementById(elmnt.id + "header")) {
            // if present, the header is where you move the DIV from:
            document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
        } else {
            // otherwise, move the DIV from anywhere inside the DIV: 
            elmnt.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e = e || window.event;
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
            elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            // stop moving when mouse button is released:
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }