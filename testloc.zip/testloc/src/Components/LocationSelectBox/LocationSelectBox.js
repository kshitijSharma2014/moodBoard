import React from "react";
import Select from "react-select";
import './locationSelectBox.css';
import { type } from "os";
import axios from 'axios';

const response = {
  "data": [
    {
      "type": "Bliss Anand pvt ltd, company_f, 92-b-93b, sector V, it manesar Narayana, 122050",
      "isprocessed": "1",
      "cntattempt": null,
      "plmid": null,
      "siteid": "site_6"
    },
    {
      "type": "kharghar Anand pvt ltd, company_f, 92-b-93b, sector V, it manesar Narayana, 122050",
      "isprocessed": "0",
      "cntattempt": null,
      "plmid": null,
      "siteid": "site_7"
    },
    {
      "type": "Nerul Anand pvt ltd, company_f, 92-b-93b, sector V, it manesar Narayana, 122050",
      "isprocessed": "0",
      "cntattempt": null,
      "plmid": null,
      "siteid": "site_8"
    },
    {
      "type": "Vashi Anand pvt ltd, company_f, 92-b-93b, sector V, it manesar Narayana, 122050",
      "isprocessed": "1",
      "cntattempt": null,
      "plmid": null,
      "siteid": "site_9"
    },
    {
      "type": "Ghansoli Anand pvt ltd, company_f, 92-b-93b, sector V, it manesar Narayana, 122050",
      "isprocessed": "1",
      "cntattempt": null,
      "plmid": null,
      "siteid": "site_10"
    }
  ]
};

const formatOptionLabel = ({ value, label, verified }) => (
  <div style={{ display: "flex" }}>
    {verified ? <div className="verifiedIcon">
      <img src={require("./verified.svg")} className="verifySvg" />
    </div> : <div className="verifiedIcon">
        <img src={require("./unverified.svg")} className="verifySvg" />
      </div>}
    <div className="locationLabel">{label}</div>
  </div>
);

class LocationSelectBox extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      sites: this.formatOptions(response),
    }
  }

  componentDidMount() {
    axios.get(`https://jiobeatplanner.st.ril.com:8082/api/plm/getPLMList?phoneno=${this.props.phoneno}`)
      .then(res => {
        const sites = this.formatOptions(res);
        this.setState({ sites });
      })
  }

  formatOptions = (response) => {
    const options = response.data.map((item)=> {
      return {
        value: item.siteid,
        label: item.type,
        verified: item.isprocessed === "1" ? true : false,
      }
    });
    return options;
  }

  onSelectedLocationChange = (selected) => {
    this.props.changeSelectedLocation(selected);
  }
  render() {
    return (
      <div className="selectBoxContainer">
        <Select
          value={this.props.selectedLocation}
          formatOptionLabel={formatOptionLabel}
          options={this.state.sites}
          placeholder='Select partner location'
          onChange={this.onSelectedLocationChange}
          styles={{
            option: base => ({
              ...base,
              'border-bottom': `1px solid #005190`,

            }),
          }}
        />
      </div>
    )
  }
}

export default LocationSelectBox;
