import React from 'react';
import './navigationBar.css';
import LocationSelectBox from '../LocationSelectBox';
import _get from 'lodash/get';
import _map from 'lodash/map';
import axios from 'axios';
import ConfirmationBox from '../ConfirmationBox';
import AlertBox from '../AlertBox';
import $ from 'jquery';
import Loader from 'react-loader-spinner'
import { encryptData, decryptData } from '../../Utils';

import "react-loader-spinner/dist/loader/css/react-spinner-loader.css"


class NavigationBar extends React.PureComponent {

  state = {
    selectedLocation: null,
    showInfoBox: true,
    toggleConfirmation: false,
    sites: [],
    showLoader: false,
  }

  componentDidMount() {
    axios.get(`${this.props.baseApi}/getPLMList?phoneno=${encryptData(this.props.phoneno)}`)
      .then(res => {
        const response = JSON.parse(decryptData(res.data.data));
        const sites = this.formatOptions(response);
        this.setState({ sites });
      })
  }

  formatOptions = (response) => {
    const options = _map(response, (item)=> {
      return {
        value: item.siteid,
        label: item.type,
        verified: item.isprocessed === "1" ? true : false,
      }
    });
    return options;
  }

  updateSites = (verifiedSite) => {
    //const newState = Object.assign({}, this.state.sites);
   // const verifiedSiteIndex = _findIndex(newState, function(site) { return site.value === verifiedSite.value; })
    debugger
    const newState = _map(this.state.sites, (site)=> {
      if (site.value === verifiedSite.value) {
        debugger
        return {
          value: site.value,
          label: site.label,
          verified: true,
        }
      }
      return site;
    });
    debugger
    this.setState({sites: newState, selectedLocation: null})
  }

  changeSelectedLocation = (selectedLocation) => {
    this.setState({ selectedLocation })
  }

  verifySelectedLocation = () => {
    const payload = encryptData(JSON.stringify({
        lat: _get(this, 'props.position.lat', '').toString(),
        lon: _get(this, 'props.position.lng', '').toString(),
        siteid: _get(this, 'state.selectedLocation.value', ''),
        phoneno: _get(this, 'props.phoneno', ''),
    }));


    this.toggleConfirmationBox();
    const that = this;
    that.setState({         
      showLoader: true,      
    })   
    $.post(`${this.props.baseApi}/VerifyPLMUserLoc`, {data: payload}, function (res) { 
      that.setState({         
        showAlertBox: true,         
        AlertText: 'Site verification Successfull!!',         
        alertType: 'success',    
        showLoader: false,   
      })       
      that.updateSites(_get(that, 'state.selectedLocation'));   
      
      setTimeout(function(){ that.props.logout(() => {})    }, 5000);

    })
    .fail(() => {
      that.setState({
        showAlertBox: true,
        AlertText: 'Site verification failed!!',
        alertType: 'failure',
        showLoader: false,
      })

    })
  }

  closeAlertBox = () => {
    this.setState({ showAlertBox: false })
  }


  toggleInfoBox = () => {
    this.setState({ showInfoBox: !this.state.showInfoBox })
  }

  hideInfoBox = () => {
    this.setState({ showInfoBox: false })
  }

  toggleConfirmationBox = () => {
    const payload = encryptData(JSON.stringify({
      lat: _get(this, 'props.position.lat', '').toString(),
      lon: _get(this, 'props.position.lng', '').toString()
    }));
    this.props.doReverseGeocodingApi(payload);
    this.setState({ toggleConfirmation: !this.state.toggleConfirmation });
  }

  render() {
    return (
      <div className="df fc">
        <div className="navHd">
          <div className="header_title">Site Locator</div>
          <img alt="jioLogo" src={require('./jioLogo.png')} className="jioLogoImg" />
        </div>
        <div className="df justifyContentCentre alignItemsCentre m-t-12 m-b-12" style={{ "height": "40px" }}>
          <LocationSelectBox
            selectedLocation={this.state.selectedLocation}
            changeSelectedLocation={this.changeSelectedLocation}
            phoneno={this.props.phoneno}
            sites={this.state.sites}
          />
          <button className="btn btn-sm btn-primary bVerify" id="bVerify" onClick={this.toggleConfirmationBox} disabled={this.state.selectedLocation === null}>Verify</button>
        </div>
        <img alt="info" src={require("./info.svg")} className="infoIconImg" onClick={this.toggleInfoBox} />
        {this.state.showInfoBox &&
          <div className="df fc infoData">
            <img alt="close" src={require("./close.svg")} className="closeSvg pa" onClick={this.hideInfoBox} />
            <div>
              Instructions for Partner Location Verrification
            </div>
            <div>
              1. Choose the Site from the above Dropdown.
            </div>
            <div>
              2. Set the RED Marker to the  correct location of your Site.
            </div>
            <div>
              3. Click the Verify Button to confirm the Location.
            </div>
          </div>}
        {this.state.toggleConfirmation && <ConfirmationBox
          buttonType='primary'
          confirmBtnClick={this.verifySelectedLocation}
          closeConfirmationBox={this.toggleConfirmationBox}
          selectedLocation={this.state.selectedLocation}
          position={_get(this, 'props.position')}
          address={this.props.address}
        />}
        {this.state.showAlertBox && <AlertBox
          AlertText={this.state.AlertText}
          alertType={this.state.alertType}
          closeAlertBox={this.closeAlertBox}
        />}
        {this.state.showLoader && <Loader 
        type="Audio"
        color="#00BFFF"
        height={100}
        width={100}
        timeout={3000}
        />}
      </div>
    );
  }
}

export default NavigationBar;
