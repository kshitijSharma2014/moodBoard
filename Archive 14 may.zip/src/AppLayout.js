import React from 'react';
import NavigationBar from './Components/NavigationBar/NavigationBar';
import Map from './Components/Map/Map';
import $ from 'jquery';
import { encryptData, decryptData } from './Utils';

const addressApiFailureMsg = 'Unable to fetch the address of the marker location';

class App extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			position: null,
			address: null,
		};
	};

	setPosition = (position) => {
		this.setState({ position });
	}
	setAddress = (address) => {
		this.setState({ address });
	}

	setInitialAddress = () => {
		const {position = null} = this.state;
		if(position !== null) {
			const getAddrpayload = encryptData(JSON.stringify({
				lat: position.lat,
				lon: position.lng
			  }));
			this.doReverseGeocodingApi(getAddrpayload)
		}
	}


	doReverseGeocodingApi = (payload) => {
		const that = this;
		$.post(`${this.props.baseApi}/GetAddress`, {data: payload}, function (res) {
			if (res === null) {
				that.setAddress(addressApiFailureMsg);
			} else {
				const response = decryptData(res.data);
				that.setAddress(response);
			}
		})
		  .fail(() => {
			that.setAddress(addressApiFailureMsg);
		  })
	  }

	render() {
		const phoneno = decryptData(this.props.phoneno)
		return (
			<div style={{"height":"100%"}}>
				<div className="navContainer">
					<NavigationBar
						position={this.state.position}
						address={this.state.address}
						phoneno={phoneno}
						doReverseGeocodingApi={this.doReverseGeocodingApi}
						baseApi={this.props.baseApi}
						logout={this.props.logout}
					/>
				</div>
				<div className="mapContainer">
					<Map
						isMarkerShown
						setPosition={this.setPosition}
						setAddress={this.setAddress}
						doReverseGeocodingApi={this.doReverseGeocodingApi}
						baseApi={this.props.baseApi}
					/>
				</div>
				<div className="app-footer pa">
					Copyright © 2020 Reliance Jio Infocomm Ltd. All rights reserved.!
				</div>
			</div>
		);
	}
};

export default App;