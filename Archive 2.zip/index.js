$('#exportTableModal').hide();


var dataSet = [
    [ "Tiger Nixon", "System Architect", "Edinburgh", "5421", "2011/04/25", "$320,800" ],
    [ "Garrett Winters", "Accountant", "Tokyo", "8422", "2011/07/25", "$170,750" ],
    [ "Ashton Cox", "Junior Technical Author", "San Francisco", "1562", "2009/01/12", "$86,000" ],
    [ "Cedric Kelly", "Senior Javascript Developer", "Edinburgh", "6224", "2012/03/29", "$433,060" ],
];

var expTable;
 
$(document).ready(function() {
    expTable = $('#exportTable').DataTable( {
        data: dataSet,
        rowReorder: {
            dataSrc: 'order',
            selector: 'tr'
          },
        columns: [
            { title: "Name" },
            { title: "Position" },
            { title: "Office" },
            { title: "Extn." },
            { title: "Start date" },
            { title: "Salary" }
        ]
    } );
} );

var exportTableCounter = 0;

$('#exportTable').css('border-bottom', 'none');
$('<div class="addRow"><button id="addRow">Add New Row</button></div>').insertAfter('#exportTable');

function openFileDataModal() {
    $('#exportTableModal').show();
}


function closeFileDataModal() {
    $('#exportTableModal').hide();
}


$("#exportTable").on("mousedown", "td .fa.fa-minus-square", function(e) {
    expTable.row($(this).closest("tr")).remove().draw();
  })

  $("#exportTable").on('mousedown.edit', "i.fa.fa-pencil-square", function(e) {

    $(this).removeClass().addClass("fa fa-envelope-o");
    var $row = $(this).closest("tr").off("mousedown");
    var $tds = $row.find("td").not(':first').not(':last');

    $.each($tds, function(i, el) {
      var txt = $(this).text();
      $(this).html("").append("<input type='text' value=\""+txt+"\">");
    });

  });

  $("#exportTable").on('mousedown', "input", function(e) {
    e.stopPropagation();
  });

  $("#exportTable").on('mousedown.save', "i.fa.fa-envelope-o", function(e) {
    
    $(this).removeClass().addClass("fa fa-pencil-square");
    var $row = $(this).closest("tr");
    var $tds = $row.find("td").not(':first').not(':last');
    
    $.each($tds, function(i, el) {
      var txt = $(this).find("input").val()
      $(this).html(txt);
    });
  });
  
  
   $("#exportTable").on('mousedown', "#selectbasic", function(e) {
    e.stopPropagation();
  });

  $('#addRow').click(function() {
    //t.row.add( [1,2,3] ).draw();
    var rowHtml = $("#newRow").find("tr")[0].outerHTML
    expTable.row.add($(rowHtml)).draw();
  });