import React from "react";
import './index.css';
import $ from 'jquery';
import { encryptData, decryptData } from './Utils';

const COUNTDOWNTIMER = 60;

class LandingPage extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            otp: '',
            warningText: '',
            OtpSent: false,
            seconds: COUNTDOWNTIMER,
        }
        this.secondsRemaining = null;
        this.intervalHandle = null;
        this.startCountDown = this.startCountDown.bind(this);
        this.tick = this.tick.bind(this);
    }

    componentDidMount() {
        this.GenerateOTP();
        this.startCountDown();
    }

    tick() {
        var sec = this.secondsRemaining - 1;
        this.setState({
            seconds: sec,
        })

        if (sec < 10) {
            this.setState({
                seconds: "0" + this.state.seconds,
            })
        }

        if (sec === 0) {
            clearInterval(this.intervalHandle);
        }
        this.secondsRemaining--
    }

    startCountDown() {
        this.intervalHandle = setInterval(this.tick, 1000);
        this.secondsRemaining = COUNTDOWNTIMER;
        this.setState({
            isClicked: true
        })
    }

    GenerateOTP = () => {
        const that = this;
        const phoneno = decryptData(this.props.phoneno);
        const payload = encryptData(JSON.stringify({
            phoneno: phoneno,
        }));

        $.post(`${this.props.baseApi}/GenerateOTP`, { data: payload }, function (res) {
            const response = decryptData(res.data);
            if (JSON.parse(response).Status === '5001') {
                that.setState({ OtpSent: true });
                that.setState({ OtpSentMessage: true })
            }
        }).fail(() => {

        })
        this.showOTPAlert();
    }


    onOtpChange = (event) => {
        this.setState({ otp: event.target.value })
    }

    onOtpSubmit = () => {
        //const that = this;
        this.props.login(() => {
            //that.props.history.push(`${that.props.history.location.pathname}/siteVerify`)

        });
    //    const otp = this.state.otp;
    //     if (otp === '') {
    //         this.setState({ warningText: 'Please enter the OTP' });
    //         this.showWarningAlert();
    //         return;
    //     }
    //     const phoneNum = decryptData(this.props.phoneno);
    //     const payload = encryptData(JSON.stringify({
    //         phone: phoneNum,
    //         otp: otp
    //     }));
    //     $.post(`${this.props.baseApi}/VerifyOTP`, { data: payload }, function (res) {
    //         const response = decryptData(res.data);
    //         if (JSON.parse(response).Status === '5001') {
    //             that.props.login(() => {
    //                 //that.props.history.push(`${that.props.history.location.pathname}/siteVerify`)
    //             });
    //         } else {
    //             that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' });
    //             that.showWarningAlert();
    //         }
    //     })
    //         .fail(() => {
    //             that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' });
    //             that.showWarningAlert();

    //         })
    }

    resendOtp = () => {
        if (this.state.seconds === '00') {
           this.setState({ OtpSent: false })
            this.GenerateOTP();
            this.startCountDown();
        }
    }

    showWarningAlert = () => {
        const that = this;
        window.setTimeout(function () {
            if (that.state.warningText !== '') {
                that.setState({warningText: ''})
            }
        }, 5000);
    } 
    
    showOTPAlert = () => {
        const that = this;
        window.setTimeout(function () {
            if (that.state.OtpSentMessage) {
                that.setState({OtpSentMessage: false})
            } 
        }, 5000);
    }

    render() {
        return (
            <div className="full_width full_height loginPageContainer">
                <img alt="jioLogo" src={require('./Components/NavigationBar/jioLogo.png')} className="jioLogoOTPpage" />
                <div className="bold otpTitle">Verify Mobile Number</div>
                {this.state.OtpSent ? <div className="otpBody">OTP has been sent to your registered mobile number. Please enter it below</div> 
                : <div className="otpBody">Please wait for the OTP...</div>}
                {/*<div className="otpBody">OTP has been sent to your registered mobile number. Please enter it below</div>*/}
                <input placeholder="Enter OTP" className="otpInputBox" type="number" maxLength="6" onChange={this.onOtpChange} />
                <button className="otpSubmit" onClick={this.onOtpSubmit}>Submit</button>
                {this.state.warningText !== '' && <div className="warningMessage">{this.state.warningText}</div>}
                {this.state.OtpSentMessage  && <div className="otpSentMessage">OTP sent to registered Mobile number</div>}
                <div id="otpResendText" className="otpResendText" ><span>Resend SMS available in </span><span>{this.state.seconds} seconds
                </span></div>
                <button className="otpResendBtn" onClick={this.resendOtp} disabled={this.state.seconds !== '00'}>Resend OTP</button>
            </div>
        );
    }
}

export default LandingPage;