import React from "react";
import ReactDOM from "react-dom";
import LandingPage from "./landing.page";
import AppLayout from './AppLayout';

import './index.css';


class App extends React.Component {
    state = {
        authenticated: false,
    }

    login = (cb) => {
        this.setState({authenticated: true});
        cb();
      }
    
      logout = (cb) => {
        this.setState({authenticated: false});
        cb();
      }
    
      isAuthenticated = () => {
        return this.state.authenticated;
      }

    render() {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const phoneno = urlParams.get('phoneno')
        const baseApi = "https://jiopulse.st.ril.com:8082/api/plm";
        return (
            <div className="App">
                {this.isAuthenticated() ?
                    <AppLayout
                        baseApi={baseApi}
                        phoneno={phoneno}
                        login={this.login}
                        logout={this.logout}
                    /> :
                    <LandingPage
                        baseApi={baseApi}
                        phoneno={phoneno}
                        login={this.login}
                        logout={this.logout}
                    />}
                {/* <Switch>
                <Route exact path="/:id" apiHeader={apiHeader} component={LandingPage} />
                <ProtectedRoute exact path="/:id/siteVerify" apiHeader={apiHeader} component={AppLayout} />
                <Route path="*" component={() => "404 NOT FOUND"} />
            </Switch> */}
            </div>
        );
    }
}

const rootElement = document.getElementById("root");
ReactDOM.render(
    <App />,
    rootElement
);