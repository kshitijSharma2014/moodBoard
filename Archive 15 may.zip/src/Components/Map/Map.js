import React from "react";
import _get from 'lodash/get';
import { encryptData } from '../../Utils';
import './map.css';

class Map extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      currPosition: null,
      showClear: false,
    }
    this.setCurrLoc = this.setCurrLoc.bind(this);
    this.onScriptLoad = this.onScriptLoad.bind(this);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(this.setCurrLoc, function () {
      });
    } else {
      console.log('error')
    }
    this.map = null;
  }

  componentDidMount() {
    if (!window.google) {
      var s = document.createElement('script');
      s.type = 'text/javascript';
      //s.src = `https://maps.googleapis.com/maps/api/js?v=3`;
      s.src = `https://maps.googleapis.com/maps/api/js?v=3&client=gme-reliancecorporate&channel=lbs_jpl_w_pr&region=IN&libraries=geometry,places,visualization`;
      var x = document.getElementsByTagName('script')[0];
      x.parentNode.insertBefore(s, x);
      s.addEventListener('load', e => {
        this.onScriptLoad();
        this.initializeSearchBox();
      })
    } else {
      this.onScriptLoad();
      this.initializeSearchBox();
    }
  }

  setCurrLoc = (position) => {
    const currPosition = {
      lat: position.coords.latitude,
      lng: position.coords.longitude
    };
    this.setState({ currPosition: currPosition })
    this.onScriptLoad();
  }

  onMapLoad = (map, position) => {
    this.marker = new window.google.maps.Marker({
      position: position,
      map: map,
      draggable: true,
      animation: true,
      title: 'My Location'
    });
    this.marker.addListener('drag', this.handleDragEvent);
    this.marker.addListener('dragend', this.doReverseGeocodingonDragEnd);
    this.props.setPosition(position);
  }


  doReverseGeocodingonDragEnd = (event) => {
    const payload = encryptData(JSON.stringify({
      lat: event.latLng.lat(),
      lon: event.latLng.lng()
    }));
    this.props.doReverseGeocodingApi(payload);
  }

  handleDragEvent = (event) => {
    const newPosition = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng()
    }
    this.props.setPosition(newPosition);
  }

  onScriptLoad = () => {
    const position = _get(this, 'state.currPosition', {
      lat: 19,
      lng: 72,
    });
    const option = {
      center: position,
      zoom: 15,
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeControl: false
    };
    if (window.google) {
      this.map = new window.google.maps.Map(
        document.getElementById('newMap'), option);
      this.onMapLoad(this.map, position);
    }

  }

  initializeSearchBox = () => {
    const input = document.getElementById('pac-input');
    this.searchBox = new window.google.maps.places.SearchBox(input);
    const that = this;
    this.map.addListener('bounds_changed', function () {
      that.searchBox.setBounds(that.map.getBounds());
    });
    that.searchBox.addListener('places_changed', function () {
      debugger;
      var places = that.searchBox.getPlaces();

      if (places.length === 0) {
        return;
      }

      // Clear out the old markers.
      // markers.forEach(function (marker) {
      //   marker.setMap(null);
      // });

      // For each place, get the icon, name and location.
      var bounds = new window.google.maps.LatLngBounds();
      places.forEach(function (place) {
        if (!place.geometry) {
          console.log("Returned place contains no geometry");
          return;
        }
        /*var icon = {
          url: place.icon,
          size: new window.google.maps.Size(71, 71),
          origin: new window.google.maps.Point(0, 0),
          anchor: new window.google.maps.Point(17, 34),
          scaledSize: new window.google.maps.Size(25, 25)
        };*/
        // Create a marker for each place.
        that.marker.setMap(null);
        that.marker = new window.google.maps.Marker({
          map: that.map,
          title: place.name,
          position: place.geometry.location,
          draggable: true,
          animation: true,
        });
        that.marker.addListener('drag', that.handleDragEvent);
        that.marker.addListener('dragend', that.doReverseGeocodingonDragEnd);
        const newPosition = {
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng()
        };
        that.props.setPosition(newPosition);

        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      that.map.fitBounds(bounds);
      debugger
      that.toggleClearMapSearch()
    });
  }

  toggleClearMapSearch = () => {
    this.setState({showClear: !this.state.showClear});
  }

  clearSearchBox = () => {
    document.getElementById('pac-input').value = '';
    this.toggleClearMapSearch();
  }

  setCurrentLocation = () => {
    const pos = this.state.currPosition;
    console.log(pos);
    this.map.setCenter(pos);
    this.map.setZoom(15);
    this.props.setPosition(pos);
    const latlng = new window.google.maps.LatLng(pos.lat, pos.lng);
    this.marker.setPosition(latlng);
    if (this.state.showClear === true) {
      this.clearSearchBox();
    }
  }

  showIcons = () => {
    if (this.state.showClear) {
      return (
        <div className="iconsContainer"><img alt="searchIcon" src={require("./searchIcon.svg")} className="searchIcon2"/> <img img alt="clear" onClick={this.clearSearchBox} src={require("./clear.svg")} className="searchClear"/></div>
      )
    } else {
      return (<img img alt="searchIcon" src={require("./searchIcon.svg")} className="searchIcon"/>)
    }
  }

  render() {
    return (
      <div style={{ width: '100%', height: '100%' }}>
        <div style={{ width: '100%', height: '100%' }} id="newMap">
        </div>
        <div className="pa searchBox">
        <input id="pac-input" className="searchGoogleMap" type="text" placeholder="Search Google Maps" />
        { this.showIcons()}
        </div>
        <div className="markerSvgContainer pa">
          <img alt="marker" src={require("./marker.svg")} onClick={this.setCurrentLocation} className="markerSvg" />
        </div>
      </div>
    )
  }
}

export default Map;