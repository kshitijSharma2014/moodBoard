import React from "react";
import Select from "react-select";
import './locationSelectBox.css';
import { dynamicsort } from '../../Utils';

// const formatOptionLabel = ({ value, label, verified }) => {
//   if (verified) {
//     return (
//       <div className="formatOption verifiedContainer">
//         <div className="verifiedIcon">
//           <img alt="verified" src={require("./verified.svg")} className="verifySvg" />
//         </div>
//         <div className="locationLabel">{label}</div>
//       </div>
//     )
//   } else {
//     return (
//     <div className="formatOption">
//       <div className="verifiedIcon">
//         <img alt="unverified" src={require("./unverified.svg")} className="verifySvg" />
//       </div>
//       <div className="locationLabel">{label}</div>
//     </div>
//     )
//   }
// }

const customStyles = {
  option: (styles, { data, isDisabled, isFocused, isSelected }) => {
    return {
      ...styles,
      fontSize: '12px',
      backgroundColor: isDisabled
        ? null
        : data.verified === 1 ? '#3a966d' : 'white',
      color: isDisabled
        ? '#ccc'
        : data.verified === 1 ? 'white' : 'black',
      cursor: isDisabled ? 'not-allowed' : 'default',
      ':active': {
        backgroundColor: '#B2D4FF',
      },
      'border-bottom': '1px solid #005190',
    }
  },
};

class LocationSelectBox extends React.Component {

  onSelectedLocationChange = (selected) => {
    this.props.changeSelectedLocation(selected);
  }

  render() {
    return (
      <div className="selectBoxContainer">
        <Select
          noOptionsMessage={() => "No sites to verify"}
          value={this.props.selectedLocation}
          //options={this.props.sites.sort(dynamicsort("verified","asc"))}
          options={[{ label: "kshitij sharma kshitij sharma kshitij sharma verified", value: "kshitij", verified: 1 }, { label: "kshitij sharma kshitij sharma kshitij sharma", value: "sharma", verified: 0 }].sort(dynamicsort("verified","asc"))}
          placeholder='Select Site location'
          onChange={this.onSelectedLocationChange}
          styles={customStyles}
        />
      </div>
    )
  }
}

export default LocationSelectBox;
