export class KPIList {
    kpiList = [
        "Total JobCodes Configured For Claim", "Total Trackee eligible for Claim", "Mobility Business", "FTTX Business", "Enterprise Business",
        "Total no. of Claims made in last 700 days", "Total no. of Claims approved in last 7 days", "Total Claims pending for L1 approval",
        "Total no. of claims submitted in JBP but in process in SAP", "Total amount of Claims made (INR) made in last 7 days",
        "Total amount of Claims approved (INR) in last 7 days", "Total number of 2 wheeler Claims made in last 7 days",
        "Total number of 4 wheelers claims made in last 7 days", "Total amount of Claims approved (INR) till now",
        "Total Distance Travelled (in km) till now", "Total number of 2 wheeler Claims made till now",
        "Total number of 4 wheelers claims made till now"
    ]
}

