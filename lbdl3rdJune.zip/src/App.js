import React from 'react';
import logo from './logo.svg';
import Home from './home/home'
import './App.css';
import OneValue from "./KPICharts/oneValue";
import WithTime from './KPICharts/withTime';

class App extends React.Component {

  state = {
    kpiSelected: null,
  }

  handleKpiChange = (kpiSelected) => {
    this.setState(
      { kpiSelected }
    );
  }

  renderKPI = (kpiSelectedValue) => {
    if (kpiSelectedValue === 0) {
      return (
        <OneValue
          props={{
            heading: "Total JobCodes configured for Claims",
            data: "http://localhost:5500/data"
          }}></OneValue>
      )
    }
    else if (kpiSelectedValue === 5) {
      return (<WithTime
        props={{
          heading: "Total claims made in last 700 days",
          data: "http://localhost:5500/data"
        }}></WithTime>)
    }
    else {
      return (<div>
        <h2>KPI not configured</h2>
        <img alt="KPI not configured" src={require("./error-message.svg")} className="errorMsg" />
      </div>)
    }
  }

  render() {
    const { kpiSelected } = this.state;
    return (
      <div className="App">
        <Home
          handleKpiChange={this.handleKpiChange}
        />
        {kpiSelected !== null && <div id="homeKPI" className="homeKPI">
          {this.renderKPI(kpiSelected.value)}
        </div>}
      </div>
    );
  }
}

export default App;
