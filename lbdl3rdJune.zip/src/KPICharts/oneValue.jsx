import React, { Component } from 'react';
class OneValue extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: null
        }
    }
    componentDidMount() {


    }
    render() {
        return (<div>
            <div>
                <h2>{this.props.heading}</h2>
            </div>
            <div>
                <h4>{this.state.value == null ? "loading..." : this.state.value}</h4>
            </div>
        </div>
        );
    }
}

export default OneValue;