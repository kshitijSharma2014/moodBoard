import React from 'react';
import PropTypes from 'prop-types';
import './navigationBar.css';
import LocationSelectBox from '../LocationSelectBox';
import _get from 'lodash/get';
import axios from 'axios';

class NavigationBar extends React.PureComponent {

  state = {
    selectedLocation: null,
    showInfoBox: false,
  }

  changeSelectedLocation = (selectedLocation) => {
    this.setState({selectedLocation})
  }

  verifySelectedLocation = () => {
    axios.post('https://jiobeatplanner.st.ril.com:8082/api/plm/VerifyPLMUserLoc', 
    { lat: this.props.lat, 
      lon: this.props.lng, 
      typ: this.state.selectedLocation.value, 
      phone: this.props.phoneno,
    })
      .then(res => {
        console.log(res);
        console.log(res.data);
      })
  }

  toggleInfoBox = () => {
    this.setState({showInfoBox: !this.state.showInfoBox})
  }

  hideInfoBox = () => {
    this.setState({showInfoBox: false})
  }

  render() {
    return (
      <div className="df fc">
      <div className="navHd">
          <div className="header_title">Site Locator</div>
          <img src={require('./jioLogo.png')} className="jioLogoImg" />
      </div>
        <div className="df justifyContentCentre alignItemsCentre m-t-12 m-b-12">
          <LocationSelectBox 
          selectedLocation={this.state.selectedLocation}
          changeSelectedLocation={this.changeSelectedLocation}
          phoneno={this.props.phoneno}
          /> 
          <button className="btn btn-sm btn-primary bVerify" id="bVerify" onClick={this.verifySelectedLocation}>Verify</button>  
        </div>   
        <img src={require("./info.svg")} className="infoIconImg" onClick={this.toggleInfoBox}/>
        {this.state.showInfoBox && 
          <div className="df fc infoData">
            <img src={require("./close.svg")} className="closeSvg pa" onClick={this.hideInfoBox} />
            <div>
              Instructions for Partner Location Verrification
            </div>
            <div>
            1. Choose the Site from the above Dropdown.
            </div>
            <div>
              2. Set the RED Marker to the  correct location of your Site.
            </div>
            <div>
              3. Click the Verify Button to confirm the Location.
            </div>
        </div>}
    </div>
    );
  }
}

export default NavigationBar;
