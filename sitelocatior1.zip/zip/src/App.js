import React from 'react';
import NavigationBar from './Components/NavigationBar/NavigationBar';
import Map from './Components/Map/Map';

import _filter from 'lodash/filter';
import _toLower from 'lodash/toLower';
import axios from 'axios';

class App extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			searchQuery: '',
			posLat: 59.0760,
			posLng: 92.8777,
		};
	};

	setCurrentLocation = () => {
		const that = this;
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(function (position) {
				debugger;
				that.setState({
					posLat: position.coords.latitude,
					posLng: position.coords.longitude,
				});

				// infoWindow.setPosition(pos);
				//infoWindow.setContent('Location found.');
				//infoWindow.open(map);
				/*map.setCenter(pos);

				map.setZoom(15);
				map.panTo(pos);*/

		// 		var marker = new google.maps.Marker({
		// 			position: pos,
		// 			map: map,
		// 			draggable: true,
		// 			crossOnDrag : false,
		// 			// raiseOnDrag : false,
		// 			animation: google.maps.Animation.DROP
		// 		});
		// 		marker.setLabel(null);
		// google.maps.event.addListener(marker, 'dragend', function (event) {
		// 			pos.lat = event.latLng.lat();
		// 			pos.lng = event.latLng.lng();
		// 			// infoWindow.open(map, marker);
		// 			});
			}, function () {
				// handleLocationError(true, infoWindow, map.getCenter());
			});
		} else {
			// Browser doesn't support Geolocation
			// handleLocationError(false, infoWindow, map.getCenter());
		}
	}

	getUrlVars() {
		let vars = [], hash;
		let hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for (let i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	}

	render() {
		const phoneno = this.getUrlVars()['phoneno'];

		return (
			<div>
				<div className="navContainer">
				<NavigationBar 
				lat={this.state.posLat}
				lng={this.state.posLng}
				phoneno={this.props.phoneno}
				/>
				</div>
				<div className="mapContainer">
				<Map
					isMarkerShown
					setCurrentLocation={this.setCurrentLocation}
					lat={this.state.posLat}
					lng={this.state.posLng}
				/>
				</div>
				<footer class="footer">
    			<p style={{'text-align': 'center', 'fontSize':'12px'}}>Copyright © 2020 Reliance Jio Infocomm Ltd. All rights reserved.!</p>
  			</footer>
			</div>
		);
	}
};

export default App;