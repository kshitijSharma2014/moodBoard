
var jobCodeTableCounter=0;
var empOrderBy = 'ilastupdatedon';

var jobCodeTable = $('#jobCodeTable').DataTable({
    "ajax": {
        url:"/FR/GetRoleData?orderBy="+empOrderBy,
        cache: true,
    },
    "language": {
        "infoEmpty": "No records available - Got it?",
    },
    "paging": true,
    "info": true,
    "retrieve": true,
    "ordering": false,
    bSortable: false,
    bProcessing: true,
    "lengthChange": false,
    "bLengthChange": false,
    "columns": [
        {
            "data": "sr_no",
            "render": function (data, type, row, meta) {
                ++jobCodeTableCounter;
                return '<div>' + jobCodeTableCounter + '</div>';
            }
        },
        {
            "data": "jobcode",
            "render": function (data, type, row, meta) {
                return '<div>' + row.jobcode + '</div>';
            }
        },
        {
            "data": "createdby",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.createdby + ' class="jobIdSelect">' + row.createdby + '</div>';
            }
        },
        {
            "data": "createdon",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.createdon + ' >' + row.createdon + '</div>';
            }
        },
        {
            "data": "MODIFIEDBY",
            "render": function (data, type, row, meta) {
                return '<div>' + row.MODIFIEDBY + '</div>';
            }
        },
        {
            "data": "modifiedon",
            "render": function (data, type, row, meta) {
                return '<div value=' + row.modifiedon + ' >' + row.modifiedon + '</div>';
            }
        },
        {
            "data": "ifavailable",
            "render": function (data, type, row, meta) {
                return '<div>' + row.ifavailable + '</div>';
            }
        },
        {
            "data": "ifmandatory",
            "render": function (data, type, row, meta) {
                return '<div>' + row.ifmandatory + '</div>';
            }
        },
        {
            "render": function (data, type, row, meta) {
                return '<img src="/Areas/Admin/images/editRow.png" class="jobRoleEdit" style="width: 14px;cursor:pointer;" id="jobRoleEdit" />' +
                    '<img src="/Areas/Admin/images/deleteRow.png" class="jobRoleDelete" style="width: 14px;margin-left: 10px;cursor:pointer;" id="jobRoleDelete"  />';
            }
        },
    ]
});
$('#jobCodeTable').removeClass('form-inline dt-bootstrap no-footer dataTable');
$('#jobCodeTable_wrapper').removeClass('dataTables_wrapper form-inline dt-bootstrap no-footer');






function onChangejobCodeSort(e) {
    let value = e.target.value;
    empOrderBy = value;
    jobCodeTableCounter = 0;
    esaTable.ajax.url("/FR/GetRoleData?orderBy=" + empOrderBy).load()
}

    function onjobCodeClick(e) {
        var jobCodeVal = e.target.id;
        $('#addJobCode').val(jobCodeVal);
        $('#jobCodeList').hide();
        $('#jobCodeList').empty();

    }

 $('#addRole').on('click', function () {

        $('#newRoleModal').show();
        dragElement(document.getElementById("newRoleModal"));
       
        $('#addJobCode').on("input", SearchEmpSolr);
    });


function SearchEmpSolr(e) {
        var queryParam = e.target.value;
        if (queryParam.length === 0) {
            $('#jobCodeList').hide();
            $('#jobCodeList').empty();
        }
        if (queryParam.length > 2) {
            var drpItems = [];
           
            $.ajax({
                type: "GET",
                url: '/FR/hotSpotSearch?srchTxt=' + queryParam + 'layerid=role',
                'Content-Type': 'application/html; charset=utf-8',
                success: function (responnse) {

                    let data = JSON.parse(responnse).response.docs || [];
                    if(data.length === 0) {
                        $('#jobCodeList').hide();
                    } else {
                        $('#jobCodeList').show();
                    }
                    $('#jobCodeList').empty();
                    data.map(function (item) {
                        $('#jobCodeList').append('<div onclick="onjobCodeClick(event)" id=' + item.jobcode + ' class="employeeId" value=' + item.jobcode + '>' + item.jobcode + '</div>');
                    });
                }
            });
            $("#addJobCode").val()
        }
    }


      $('#jobCodeTable').on('click', 'tbody .jobRoleEdit', function () {
        var data_row = empTable.row($(this).closest('tr')).data();
        jobRoleEditMode = true;
        $("#newRoleModal").show();
       $('#jobCodeInput').val(data_row.jobcode);
        $("#jobCodeInput").prop('disabled', true);
        $("input[name=jobCodeMandatory][value=" + data_row.ifmandatory + "]").attr('checked', 'checked');
       $("input[name=jobCodeAvailable][value=" + data_row.ifavailable + "]").attr('checked', 'checked');
       $("input[name=jobCodeRegistered][value=" + data_row.ifregistered + "]").attr('checked', 'checked');
    });



function addJobRoleRow() {

    var datatableData = {
        ifmandatory: $("input[name=jobCodeMandatory]").val(),
        ifavailable: $("input[name=jobCodeAvailable]").val(),
        ifregistered: $("input[name=jobCodeRegistered]").val(),
       jobcode: $('#jobCodeInput').val(),
    }

     $.ajax({
            type: "POST",
            url: '/ClaimManagementAccess/UpdateEmpClaimAccess',
            data: { 'jobCodedata': datatableData },
            'Content-Type': 'application/json; charset=utf-8',
            async: false,
            success: function (data) {
                
             }
        });
        });
        closeEmpModal();
}


function closeJobRoleModal() {
        $('#jobCodeInput').val('');
        $('#jobCodeList').empty();
        $("#jobCodeInput").prop('disabled', false);
        $('#jobCodeList').hide();
        $('#newRoleModal').hide();

}

