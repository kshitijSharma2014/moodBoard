var CryptoJS = require("crypto-js");

const key = CryptoJS.enc.Utf8.parse('8080808080808080');  
const iv = CryptoJS.enc.Utf8.parse('8080808080808080');  

export const encryptData = (data) => {
    const encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(data)), key,  
    {
       iv: iv,  
       mode: CryptoJS.mode.CBC,  
       padding: CryptoJS.pad.Pkcs7 
    });  
    return encrypted;
}

export const decryptData = (data) => {
    var decrypted = CryptoJS.AES.decrypt(data, key, { 
            iv : iv
        });
    return decrypted.toString(CryptoJS.enc.Utf8);
}