import React from "react";
import auth from "./auth";
import _get from 'lodash/get';
import './index.css';
import $ from 'jquery';
import { encryptData, decryptData } from './Utils';


class LandingPage extends React.Component {

    state = {
        otp: '',
        warningText: '',
        OtpSent: false,
    }

    componentDidMount() {
     //  this.GenerateOTP();
    }

    GenerateOTP = () => {
        const phoneNum = decryptData(encodeURI(this.props.location.pathname).slice(1));
        const payload = encryptData({
            phone: phoneNum,
        });
        $.post("http://localhost:53400/api/plm/GenerateOTP", payload, function (res) {
            const response = decryptData(res);
            if (JSON.parse(response).Status === 5001) {
                this.setState({ OtpSent: true })
            }
        }).fail(() => {

        })
    }


    onOtpChange = (event) => {
        this.setState({ otp: event.target.value })
    }

    onOtpSubmit = () => {
        const otp = this.state.otp;
        if (otp === '') {
            this.setState({ warningText: 'Please enter the OTP' })
            return;
        }
        const phoneNum = decryptData(encodeURI(this.props.location.pathname).slice(1));
        const payload = encryptData({
            phone: phoneNum,
            otp: otp
        });
        const that = this;
        $.post("http://localhost:53400/api/plm/VerifyOTP", {input: payload}, function (res) {
            const response = decryptData(res);
            if (JSON.parse(response).Status === 5001) {
                auth.login(() => {
                    that.props.history.push("/siteVerify");
                });
            } else {
                that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' })
            }
        })
            .fail(() => {
                that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' })

            })
    }

    render() {
        return (
            <div className="full_width full_height loginPageContainer">
                <img alt="jioLogo" src={require('./Components/NavigationBar/jioLogo.png')} className="jioLogoOTPpage" />
                <div className="bold otpTitle">Verify Mobile Number</div>
                {this.state.OtpSent && <div className="otpBody">OTP has been sent to your registered mobile number. Please enter it below</div>}
                <input placeholder="Enter OTP" className="otpInputBox" type="number" onChange={this.onOtpChange} />
                <button className="otpSubmit" onClick={this.onOtpSubmit}>Submit</button>
                {this.state.warningText !== '' && <div className="warningMessage">{this.state.warningText}</div>}
                <div className="otpResend"><span>Click here to resend otp: </span><span>60</span></div>
            </div>
        );
    }
}

export default LandingPage;