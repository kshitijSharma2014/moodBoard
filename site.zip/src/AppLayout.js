import React from 'react';
import NavigationBar from './Components/NavigationBar/NavigationBar';
import Map from './Components/Map/Map';

class App extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			position: null,
		};
	};

	getUrlVars() {
		let vars = [], hash;
		let hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for (let i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	}

	setPosition = (position) => {
		this.setState({ position });
	}

	render() {
		const phoneno = this.getUrlVars()['phoneno'];
		return (
			<div style={{"height":"100%"}}>
				<div className="navContainer">
					<NavigationBar
						position={this.state.position}
						phoneno={phoneno}
					/>
				</div>
				<div className="mapContainer">
					<Map
						isMarkerShown
						setPosition={this.setPosition}
					/>
				</div>
				<div className="app-footer pa">
					Copyright © 2020 Reliance Jio Infocomm Ltd. All rights reserved.!
				</div>
			</div>
		);
	}
};

export default App;