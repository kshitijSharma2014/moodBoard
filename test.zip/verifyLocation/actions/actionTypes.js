export const GET_PARTNER_LOCATIONS = 'get_partner_locations';
export const GET_PARTNER_LOCATIONS_PENDING = 'get_partner_locations_pending';
export const GET_PARTNER_LOCATIONS_SUCCESS = 'get_partner_locations_success';
export const GET_PARTNER_LOCATIONS_ERROR = 'get_partner_locations_error';

export const VERIFY_PARTNER_LOCATION = 'verify_partner_location';
export const VERIFY_PARTNER_LOCATION_PENDING = 'verify_partner_location_pending';
export const VERIFY_PARTNER_LOCATION_SUCCESS = 'verify_partner_location_success';
export const VERIFY_PARTNER_LOCATION_ERROR = 'verify_partner_location_error';