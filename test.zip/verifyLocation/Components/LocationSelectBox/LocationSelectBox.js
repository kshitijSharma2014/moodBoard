import React from "react";
import Select from "react-select";
import './locationSelectBox.css';
import { type } from "os";
import axios from 'axios';

const options = [
  { value: "Abe", label: "Abe", verified: true },
  { value: "John", label: "John", verified: false },
  { value: "Dustin", label: "Dustin", verified: true },
  { value: "Dustin123", label: "Dustin123", verified: true },
  { value: "Dustin456", label: "Dustin456", verified: false },
  { value: "DustinJo", label: "Dustin john", verified: false },
  { value: "DustinAbe", label: "Dustin abe", verified: true },
];

const formatOptionLabel = ({ value, label, verified }) => (
    <div style={{ display: "flex"}}>
      {verified ? <div className="verifiedIcon">
      <img src="icons/verified.svg" className="verifySvg" />
      </div> : <div className="verifiedIcon">
      <img src="icons/unverified.svg" className="verifySvg" />
      </div>}
      <div className="locationLabel">{label}</div>
    </div>
  );

class LocationSelectBox extends React.Component {


  componentDidMount() {
    axios.get(`https://jiobeatplanner.st.ril.com:8082/api/plm/getPLMList`, { phoneno: phoneno })
      .then(res => {
        const sites = res.data;
        this.setState({ sites });
      })
  }

  onSelectedLocationChange = (selected) => {
    this.props.changeSelectedLocation(selected);
  }
    render() {
        return(
            <div className="selectBoxContainer">
            <Select
                formatOptionLabel={formatOptionLabel}
                options={options}
                placeholder='Select partner location'
                onChange={this.onSelectedLocationChange}
                styles={{
                  option: base => ({
                    ...base,
                    'border-bottom': `1px solid #005190`,
                    
                  }),
                }}
            />
            </div>
        )
    }
}

export default LocationSelectBox;
